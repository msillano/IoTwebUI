/*
This file is part of IoTwebUI project (https://github.com/msillano/IoTwebUI)
 contains two custom callback functions: getIcon(), filterDP()
 ------------------------------
License MIT
(C)2024 marco.sillano@gmail.com
version 2.2 28/08/2024
version 2.0 30/05/2024
version 1.1 20/05/2024
version 1.0 15/05/2024
*/
// ============ local functions	(CUSTOMIZATION optional)
//	


function getIcon(res, type = 'device', connected = false){
// USER TODO ======= Customize icon for some special devices.	
// To select a/all 'special' devices you can use any of:
// - res.name (or res.id)
// - res.product_name
// - res.category
// see https://fontawesome.com/v4/cheatsheet/
	 var   theIcon = {  // default std devices
                    code: "\uf1b2",   // fa-cube
                    color: "HotPink", // default color
                    };
  // ========  NOT std DEVICE ICONS					
	      if (type == 'root')      //  special ROOT icon
             return { code: "\uf174", color: "OrangeRed", size:80 };
          if (type == 'home')      // tuya home :  fa-home
             return { code: "\uf015", color: "DarkSlateGray", size:80};
          if (type == 'room')      // tuya room :  fa-circle
             return { code: "\uf111", color: "SlateGray"};
 // SPECIAL  virtual devices (default)		 
	      if (type == 'x-device'){  // user x-device :  fa-gear
				theIcon['code']  =  "\uf085";
		        theIcon['color'] =  "DarkGreen"; 
                };
	      if (type == 'virtual')  // tuya virtual :  fa-cube
               theIcon['color']  =  "Green";
			 
 // ==== TODO CUSTOMIZATION icon for special user devices	   
 // EXAMPLE: This works on my system:	 
          if ((res.name.startsWith("Temp")) || (res.name.startsWith("TF_"))){
                     theIcon['code'] = "\uf2c8";
            } else if (res.name.startsWith("Termo")) { 
                     theIcon['code'] = "\uf045";
            } else if (res.name.includes("Gateway")) {
                     theIcon['code'] = "\uf1eb";
            }
			
// ===== USER TODO ENDS			
	if (!connected) theIcon['color'] =	"DarkGray";
    return (theIcon);
}
// CUSTOM local decode function from tuyaDAEMON.CORE_deviced.ENCODE/DECODE user library, modified
// EXAMPLE DECODE USE
 function datadecodeSTRUCTELERT(value) {
   let result = {
    };
     // rewritten javascript version (Buffer not available in browser)
	const decod = atob(value);  // ASCII string from code64
	// Int16BE conversion:
	result["V"] =     (decod.charCodeAt(1) + 256*decod.charCodeAt(0)) / 10.0;    // V
 	result["Leack"] = (decod.charCodeAt(3) + 256*decod.charCodeAt(2)) / 1000.0;  // A
 	result["A"] =     (decod.charCodeAt(5) + 256*decod.charCodeAt(4)) / 40000.0; // A
 	result["W"] =     (decod.charCodeAt(7) + 256*decod.charCodeAt(6)) ;  // W
 /*  nodejs version
    const b = Buffer.from(value, "base64");
    result["V"] = b.readUInt16BE(0) / 10.0;       // V
    result["Leack"] = b.readUInt16BE(2);          // mA
    result["A"] = b.readUInt16LE(4) / 40000.0;    // A
    result["W"] = b.readUInt16BE(6) ;             // W
*/	
    return (result);
};

function filterDP(res, devData = {status: "none"}){
  if 	(devData == null) devData = {status: "none"};
  
// USER TODO ======= Customize for tooltip optimization.	
// To select a/all 'special' devices you can use any of:
// - res.name (or res.id)
// - res.product_name
// - res.category
//  input/output are object like this: { property1:value1, property2:value2,...}

// EXAMPLE: This works on my system:	 
 	 if (res.name.startsWith("Termo")) {   //Thermovalves for radiators
// in these devices, the temperature is an integer (*10), i.e. the value 237 is 23.7° 
// simple decode of data value for better visualization, overwrite the old value
		 devData.temp_set = ((devData.temp_set) / 10).toFixed(1)+'°C';
	     devData.temp_current = ((devData.temp_current) / 10).toFixed(1)+'°C';
	 }
	 
// EXAMPLE: decoding data and adding new value to device	 
// The device "Main AC" is with the vital "phase_a" value coded (see https://github.com/msillano/IoTwebUI/blob/main/RESTserver/LEGGIMI-REST22.md#customizzazioni )	 
 if (res.name == "Main AC") {   //Power meter 
// decode for tooltip, adds new values:
      const vals = datadecodeSTRUCTELERT(devData.phase_a);
      devData['phase_a_V'] = vals.V.toFixed(1);
      devData['phase_a_Leack'] = vals.Leack.toFixed(3);
      devData['phase_a_A'] = vals.A.toFixed(3);
      devData['phase_a_W'] = vals.W.toString();
 // MORE: To Export via IOTrest the decoded value, we add it to device.status as "phase_a_decoded" 
      addToStatus("Main AC","phase_a_decoded", vals) ;
  }
// ..... here more ....	 
// ============ CUSTOMIZATION ENDS
	 
	 return devData;    
 }
 
// TAP-TO-RUN color
//  default:
//  disabled:gray; local: green; lan: yellow; other-cloud: blue
// custom: use constants like    
// btn-primary or  btn-outline-primary : blue
// ... more: (see https://getbootstrap.com/docs/4.0/components/buttons/)
/*
id:"Jb3VfhxDgqOWUABC"
name: "ALARM OFF"
running_mode:"cloud"
space_id:"10234820"
status:"enable"
type:"scene"  i.e. tap-to-run
*/
function sceneColor(scene){
	         if (scene.status == 'disable') return 'btn-secondary';
	         if (scene.running_mode == 'local') return 'btn-success';
	         if (scene.running_mode == 'lan') return 'btn-warning';		 
			 return ('btn-primary');
}

IOTrest: add-on REST server for IoTwebUI 2.2
------------------------
This function is optional, if not required, nothing to do!
For capabilities, installation and use see:
 https://github.com/msillano/IoTwebUI/blob/main/RESTserver/LEGGIMI-REST22.md (italiano)
 https://github.com/msillano/IoTwebUI/blob/main/RESTserver/README-REST22.md (english)
/*
This file is part of IoTwebUI project (https://github.com/msillano/IoTwebUI)
 Contains user data and options 
 ------------------------------
License MIT
(C)2024 marco.sillano@gmail.com
version 1.2 20/05/2024
*/
// ========== CONFIG data: USER MUST UPDATE IT (MANDATORY)
//	
      const data_center = "https://openapi.tuyaeu.com";         // update if required
//	  const icon_prefix = "https://images.tuyaeu.com";          // to get Tuya icons (not used)
//
// +++++++++ Tuya CREDENTIALS from: plataform.Tuya/cloud + [open projec] /overview
      const client_id   = "123456789";               // here your ID
      const secretkey   = "abcdef12345678";   // here your secret key

// ======== LOGGING USER OPTIONS (OPTIONAL)
// logFormat: control the file output format: one off  "CSV" | "JSON" | "NONE"
//  note: NONE == NO LOGGING
	  const logFormat = "NONE";
	  
// autosave: time interval for autosave log (if "CSV" | "JSON") in hours 
// note  0 = NO AUTOSAVE	  
      var autoSave = 0;
	  
// loglist: Defines data in LOG file: one row for value
// format: { home: "hhh", device: "ddd", status:"ppp" (name)},  (editing care to -"-, -,-)
//  where: hhh=  name or home_ID of a HOME, 
//         ddd=  name or ID of a device, 
//         ppp=  name of a property ( as in tooltip) 
// EXAMPLE:	  
      const loglist =[
          { home: "ROMA", device: "TF_frigo", status:"va_temperature"}, 
		  { home: "ROMA", device: "Temperatura studio", status:"va_temperature"},
		  ];

// ========  Timings (OPTIONAL)		  
// note:  tuyaInterval MIN = 20 s (forced)	  
// note:  logInterval  MIN = 60 s (forced) 
      var tuyaInterval = 1*60;   // in seconds - best min 30  max 10*60
      var logInterval =  5*60;   // in seconds - best  min 2*60 max 30*60 (bigger than tuyaInterval) 

// ========  Look&Feel (OPTIONAL)
// buttonsInteraction: show buttons for pan/zoom (else only mouse).
      const buttonsInteraction = true;

// =======  Exclude HOMES (VER 1.2 - OPTIONAL)
// In case of many homes, to get a smaller tree, array of ignored homes 
// note: also data logging exclusion
// format: { "hh1", "hh2"...}, 
//    where: hh1/hh2=  names or home_IDs of homes (also NOT existing at all) 
// EXAMPLE:
      const hide_homes = [
	                    '192110395',
						'MILANO'
						 ];

// ======== CONFIG data ends.
 
/*
This file is part of IoTwebUI project (https://github.com/msillano/IoTwebUI)
 Contains user data and options 
 ------------------------------
License MIT
(C)2024 marco.sillano@gmail.com
version 2.0 30/05/2024
*/
// ========== CONFIG data: USER MUST UPDATE IT (MANDATORY)
//	
//     const data_center = "https://openapi.tuyaus.com";         // update if required
       const data_center = "https://openapi.tuyaeu.com";         // update if required
//	  const icon_prefix = "https://images.tuyaeu.com";          // to get Tuya icons (not used)
//
// +++++++++ Tuya CREDENTIALS from: plataform.Tuya/cloud + [open project] /overview
//      const client_id   = "123456789";               // here your ID
//      const secretkey   = "abcdef12345678";   // here your secret key
      const client_id   = "123456789";               // here your ID
      const secretkey   = "abcdef12345678";   // here your secret key
 	  
// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
// ===================== LOGGING USER OPTIONS (OPTIONAL)
// logFormat: control the file output format: one off  "CSV" | "JSON" | "NONE"
//  note: NONE == NO LOGGING
	  const logFormat = "CSV";
	  
// autosave: time interval for autosave log (if "CSV" | "JSON") in hours 
// note  0 = NO AUTOSAVE	  
      var autoSave = 2;
	  
// loglist: Defines data in LOG file: one row for value
//  2 formats, Array of Objects or JSON string(Export):
//        { home: "hhh", device: "ddd", status:"ppp" },  (editing: care to -"-, -`-, commas)
//    where: hhh=  name or home_ID of a HOME, 
//         ddd=  name or ID of a device, 
//         ppp=  original name of a property (in tooltip can be customized)
//
// Since v.2.0: THE 'loglist' CAN BE CREATED FROM THE APP - EXPERT MODE.
// COPY IT HERE TO MAKE YOUR CHOICES PERMANENT (attention to little backslash "`" initial and final).
// EXAMPLE (object list): (accepts also NOT existing at all)  
      const logList =[
          { home: "ROMA", device: "TF_frigo", status:"va_temperature"}, 
		  { home: "ROMA", device: "Temperatura studio", status:"va_temperature"},
		  { home: "ROMA", device: "Temperatura tudio", status:"va_temperature"},
		  ];


// ===================== ALERT USER OPTIONS (OPTIONAL)
// testList: Defines observed data and alert conditions.
//  here:  device=  name or ID of a device, 
//         property = name of a variable in the device
//         condition = one of: "grt"|"equ"|"lst"
//         value = the test value: number or string (e.g. 34, false...)
//         message: text (for pop|voice) or URL or Tap-to-run name (optional)
//         action = 0..3 from: 'beep', 'pop', 'sound', 'voice'. (URLs and tap-to-run|RULE auto)
//  2 formats, Array of Objects or JSON string(Export):
// Since v.2.0: THE 'testList' CAN BE CREATED FROM THE APP - EXPERT MODE.
// COPY IT HERE TO MAKE YOUR CHOICES PERMANENT (attention to little backslash "`" initial and final).
// EXAMPLE (JSON):	(accepts also NOT existing at all)  
 const testList = `  [
	{
		"device": "Temperatura soggiorno",
		"property": "va_humidity",
		"condition": "grt",
		"value": "40",
		"action": [
			"beep"
		]
	},
	{
		"device": "Sensore porta",
		"property": "doorcontact_state",
		"condition": "equ",
		"value": "true",
		"message": "La porta di casa è aperta. Chi sarà?",
		"action": [
			"voice"
		]
	},
	{
		"device": "tuya_bridge",
		"property": "switch_1",
		"condition": "equ",
		"value": "true",
		"message": "Sono chiuso per sempre",
		"action": [
			"pop",
			"beep",
			"voice"
		]
	}
] `; 


// ==============================  Timings (OPTIONAL)		  
// note:  tuyaInterval MIN = 20 s (forced)	  default: 120 s
// IMPORTANT! Tuya limit 26000/month, i.e. tuyaInterval = 120 !!
// note:  logInterval  MIN = 60 s (forced)    default:  5 min.
      var tuyaInterval =  20;   // in seconds - best: min 30  max 10*60
      var logInterval =  4*60;   // in seconds - best  min 2*60 max 30*60 (bigger than tuyaInterval) 

// ==============================  Exclude HOMES (OPTIONAL)
// In case of many homes, to get a smaller tree, fill the array by ignored homes 
// note: also data logging exclusion.
// format: { "hh1", "hh2"...}, 
//    where: hh1/hh2=  names or home_IDs of homes (also NOT existing at all) 
// EXAMPLE:
      const hide_homes = [
	                    'MILANO',
						'CIRCE',
					    ];
						
// ==============================  Exclude TAP-TO-RUN (OPTIONAL)
// Some tap-to-run are non for user action, fill the array by ignored TAP-TO-RUN 
// format: { "tt1", "tt2"...}, 
//    where: tt1/tt2=  names or IDs of TAP-TO-RUN (accepts also NOT existing at all) 
// EXAMPLE:
      const hide_scenes = [
	                    '192110395',
						'Accendi luce bagno',
					    ];			
						 
// ==============================  Look&Feel EXPERT MODE (OPTIONAL)
// to disable the 'expert' mode 
      const expertModeEnabled = true;
	  
// ==============================  Look&Feel SPEECH RECOGNITION (OPTIONAL)
// to config the 'SpeechRecognition' function 
      const SpeechRecognitionEnabled = true;
	  var SpeechRecognitionNeverEnds = false;
	  
// ==============================  Look&Feel NAVIGATION (OPTIONAL)
// buttonsInteraction: show buttons for pan/zoom (else only mouse).
      const buttonsInteraction = true;

// =============================  Look&Feel BEEP SOUND for ALERT (OPTIONAL)
// can be changed, local or remote - Examples:
// const beepFile = 'https://media.geeksforgeeks.org/wp-content/uploads/20190531135120/beep.mp3';
     const beepFile = 'beep.mp3';
 
// =============================  Look&Feel ALERT ICON (OPTIONAL)
//   note: default Tuya, color: Lime 
     const alertIcon = { code: "\uf174", color: "Lime"  };
 
// ======== CONFIG data ends.
 
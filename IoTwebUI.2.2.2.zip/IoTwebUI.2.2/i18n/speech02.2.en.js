/*
This file is part of IoTwebUI project (https://github.com/msillano/IoTwebUI)
contains a customizable/translable function: processCommands()
------------------------------
License MIT
(C)2024 marco.sillano@gmail.com
version 2.1 17/06/2024
 */
 /* English sentences: 
   'Hey Tuya, run|activate (the|a|...) xxx (a|for|...)(yyy) (a|for|...) (zzz)' (xxx (yyy) (zzz) = > tap-to-run|RULE name)
   'Hey Tuya, back'| 'Hey Tuya, (at) home'
   'Hey Tuya, go (to|...) RULES'
   'Hey Tuya, go (to|...) SCENES'
   'Hey Tuya, go home'
   'Hey Tuya, STOP (the|...) voice'
   'Hey Tuya, (in|to...) EXPERT mode'
   'Hey Tuya, (in|to...) USER mode'
   'Hey Tuya, VOICE (in|to...) continuous mode'
   'Hey Tuya, VOICE (on|...) demand'
   'Hey Tuya, STOP (the) voice'
   
    Note. The use of 'particelle' like (the|a|...) is optional. The goal is to have sentences that make sense and increase recognition by SpeechRecognition engine.
  */
// ============ SpeechRecognition  ENGLISH (experimental)
	 let particelle = ['the', 'a', 'an', 'to', 'from', 'with', 'by', 'in', 'on', 'at', 'near', 'for', 'far', 'of', 'as','now'];

// 
function speechEvents(parts) {
//  console.log('SPEECH parts', parts);
    if (['e', 'ok', 'ehi', 'ehy'].includes(parts[0].toLowerCase()))
        if (['tuya', 'tuia', 'giulia', 'julia'].includes(parts[1].toLowerCase())) {
			statusInit = false;
			if ((parts.length > 2) && (parts[2] != '?')){
				parts.splice(0,2);
//				console.log("LONG", parts);
				processCommands( parts);
			} else {
			    voiceMessage(JsTxt[83]);
			}
			
}  else {
            voiceMessage( JsTxt[84]);
        }
}

function processCommands(parts){
		// EXPERIMENTAL  english syntax implementation
		//   [Hey, Tuya,]  (on|the...) AAAA (on|the...) BBBB
		//   becomes: AAAA BBBB
		//   (on|the...): see 'particelle' array.	 
             if (particelle.includes(parts[0].toLowerCase())){
                  parts.splice(0,1);
			 }
             if (particelle.includes(parts[1].toLowerCase())){
                    parts.splice(1,1);
			 }
// console.log(parts);
            switch (parts[0].toLowerCase()) {
                // here verbs...
            case "run":
            case "activate":
            case "runs":
            case "activates":
               // 'Hey Tuya, run|activate (the|a|...) xxx (a|for|...)(xxx) (a|for|...) (xxx)' (tap-to-run|RULE)
                // tap to run|RULE name: one, two or three words, with exclusion of particelle[] words.
                let st = parts[1];
                let s1 = getScene(st);
				let idx = ignoreIndexOf(ruleNames, st);
                if (!(s1) && (idx == -1)) {
					if (particelle.includes(parts[2].toLowerCase())){
						parts.splice(2,1);
						}
                    st += " " + parts[2];
                    s1 = getScene(st);
					idx = ignoreIndexOf(ruleNames, st);
                }
                if (!(s1) && (idx == -1)) {
				   if (particelle.includes(parts[3].toLowerCase())){
						parts.splice(3,1);
						}
                    st += " " + parts[3];
                    s1 = getScene(st);
					idx = ignoreIndexOf(ruleNames, st);
                }
                if (s1) {
                   voiceMessage( JsTxt[85] + st + "'.");
                   setTimeout(doTTR, 80, s1);
 				     } else
                if (idx > -1){
					let index = runRule.indexOf(ruleNames[idx]);  // more calls?
                    if (index == -1) {
		             	runRule.push(ruleNames[idx]);  
		            }
					voiceMessage( JsTxt[86] + st + "'.");
					extraRun = true;
					setTimeout(pollingRules, 80);
				} else
                    voiceMessage(JsTxt[87] + st);
                break;
            case "back":
            case "home":
                // 'Hey Tuya, back'
                // 'Hey Tuya, (at) home'
                if (document.getElementById("rule-section").style.display == 'block') {
                    setTimeout(toggleRule, 50, false);
                } else
                    if (document.getElementById("tap-section").style.display == 'block') {
                        setTimeout(toggleTap, 50, false);
                    } else
                        beep();
                break;
            case "go":
                switch (parts[1].toLowerCase()) {
                    // 'Hey Tuya, go (to) RULES (new RULE page)
                case "rule":
                case "rules":
                    if (categories) {
                        if (document.getElementById("tree-section").style.display == 'block') {
                            setTimeout(toggleRule, 50, false);
                        } else
						    beep();
                     } else
                        voiceMessage( JsTxt[88]);
                    break;
                case "scene":
                case "scenes":
                    // 'Hey Tuya, go (to) SCENES' (to tap-to-run page)
                    if (document.getElementById("tree-section").style.display == 'block') {
                        setTimeout(toggleTap, 50, false);
                    } else
                        beep();
                    break;
                case "home":
                    // 'Hey Tuya, go home'
                    if (document.getElementById("rule-section").style.display == 'block') {
                        setTimeout(toggleRule, 50, false);
                    } else
                        if (document.getElementById("tap-section").style.display == 'block') {
                            setTimeout(toggleTap, 50, false);
                        } else
                            beep();
                    break;

                } //  end case 'go'
                break;
			case "stop":
		   	   // Hey Tuya, STOP (the) voice
			      if (  ['voice','voices'].includes(parts[1].toLowerCase()) ) {
					 voiceends();  
				  }
				  break;
            case "expert":
                // Hey Tuya, (in) EXPERT mode
                  if ( ['mode'].includes(parts[1].toLowerCase()) ) {
                    if ((!categories) && expertModeEnabled) {
                        expertMode(false);
                        voiceMessage(JsTxt[89]);
                    } else {
                        if (categories)
                            voiceMessage(JsTxt[90]);
                        else
                            beep();
                    } 					
                    break;
                   }
				   break;
                // Hei Tuya, (in) USER mode'
            case "user":  
			case "users":
                if ( ['mode'].includes(parts[1].toLowerCase()) ) {
                    if (categories) { //i.e EXPERT mode
                        expertMode(false);
                        voiceMessage(JsTxt[91]);
                    } else {
                        voiceMessage(JsTxt[92]);
                    }
                    break;
                  }
	             break;
            case "voice":  
			case "voices":
              // Hey Tuya, VOICE continuous mode'  		
				 if ((parts[1].toLowerCase() == 'continuous') && (['mode'].includes(parts[2].toLowerCase()))){
					SpeechRecognitionNeverEnds = true;
					document.getElementById("offbutton").style.display = "inline"; 
					document.getElementById("voicebutton").disabled = true;
		            document.getElementById("offbutton").disabled = false;
                    break;
				 } 
             // Hey Tuya, VOICE (on) demand'
   				 
                 if (['demand'].includes(parts[1].toLowerCase()))  {
 					SpeechRecognitionNeverEnds = false;
					document.getElementById("offbutton").style.display = "none"; 
					document.getElementById("voicebutton").disabled = true;
		            break;
				 } 				 
                break;
            default:
                voiceMessage(JsTxt[93]);
            } // end case 'ehi Tuya'
       statusInit = true;
}

// =================================== locals

var statusInit  = true; 
//
function voiceMessage(text) {
    document.getElementById("voice").innerText = text;
}

// ================================== voice startup
var recognition = null;

if (SpeechRecognitionEnabled) {
    try {
        var SpeechRecognition = SpeechRecognition ||
                                webkitSpeechRecognition ||
                                mozSpeechRecognition ||
                                msSpeechRecognition ||
                                oSpeechRecognition;
  // var SpeechGrammarList = SpeechGrammarList || window.webkitSpeechGrammarList
  // var SpeechRecognitionEvent = SpeechRecognitionEvent || webkitSpeechRecognitionEvent

        recognition = new SpeechRecognition();
    } catch (e) {
        console.error(e);
        myMsgBox(JsTxt[94], JsTxt[95]);
        document.getElementById("voicediv").style.display = "none";
        document.getElementById("mynetwork").style.height = "86vh";
    }
 if (SpeechRecognitionNeverEnds) {
		   document.getElementById("offbutton").disabled = true;
	   } else {
		   document.getElementById("offbutton").style.display = "none";
	   }
	
} else {  // i.e. user disabled
    document.getElementById("voicediv").style.display = "none";
    document.getElementById("mynetwork").style.height = "86vh";
}

if (recognition)
    console.log('SpeechRecognition enabled.');
// ========================================================
// see https://github.com/TalAter/annyang/blob/master/src/annyang.js
function voicestart() {
	if (recognition){
		recognition.continuous = true;
		try {
			recognition.start();
			console.log('voice started');
		} catch (e) {}
	}
}
function voiceRestart() {
	if (recognition){
		recognition.continuous = true;
		try {
			recognition.start();
     	} catch (e) {}
	}
}
var useroff = false;
function voiceends() {
	if (recognition){
		try {
			useroff = true;
			recognition.abort();
		} catch (e) {}
	}
}
// ========================================== callbacks
if (recognition) {
    recognition.onstart = function () {
       document.getElementById("offbutton").disabled = false;
       document.getElementById("voicebutton").disabled = true;
       voiceMessage(JsTxt[96]);
    }
    recognition.onspeechend = function () {
 	   if (!SpeechRecognitionNeverEnds)
              document.getElementById("voicebutton").disabled = false;
        voiceMessage(JsTxt[97]);
    }
    recognition.onerror = function (event) {
        if (event.error == 'no-speech') {
            voiceMessage( JsTxt[98]);
            recognition.abort();
     	   if (!SpeechRecognitionNeverEnds)
                 document.getElementById("voicebutton").disabled = false;
        };
    }
   recognition.onend = function (event) {
	   if ((SpeechRecognitionNeverEnds) && (!useroff ))
            setTimeout(voiceRestart, 300);
	   if(useroff){
		document.getElementById("voicebutton").disabled = false;
		document.getElementById("offbutton").disabled = true;
		 voiceMessage(' JsTxt[99]');
		useroff = false;
        };   
	
    }

    recognition.onresult = function (event) {
        // event is a SpeechRecognitionEvent object.
        // It holds all the lines we have captured so far.
        // We only need the current one.
        //      console.log('voice', event);
        var current = event.resultIndex;
        // Get a transcript of what was said.
         var transcript = event.results[current][0].transcript;
        voiceMessage(transcript);
        let parts = (transcript + " ? ? ?").split(' ');
        // cleanup
        while (((parts[0] === '') || (parts[0] === '?')) && (parts.length > 1)) {
            parts.shift();
        }
        if (parts.length < 2)
            return;
        //
		if (statusInit){
            speechEvents(parts);
		} else {
			console.log("SHORTS", parts);

			processCommands(parts);
		}
    }
}

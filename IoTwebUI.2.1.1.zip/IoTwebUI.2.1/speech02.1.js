/*
This file is part of IoTwebUI project (https://github.com/msillano/IoTwebUI)
contains two custom callback functions: getIcon(), filterDP()
------------------------------
License MIT
(C)2024 marco.sillano@gmail.com
version 2.1 17/06/2024
 */
// ============ local functions	(CUSTOMIZATION optional)
// 
function speechEvents(parts) {
//  console.log('SPEECH parts', parts);
/*
// RULE usate per prove:
   if (TRIGBYNAME('spegni la luce')) VOICE ("Fatto: 'spegni la luce'");
   if (TRIGBYNAME("Pippo")) VOICE ("Trovato Pippo");
   if (TRIGBYNAME("chiamata per Pippo")) TRIGRULE("pippo"), VOICE("chiamo Pippo");
*/
    if (['e', 'ok', 'ehi', 'ehy'].includes(parts[0].toLowerCase()))
        if (['tuya', 'tuia', 'giulia', 'julia'].includes(parts[1].toLowerCase())) {
			statusInit = false;
			if ((parts.length > 2) && (parts[2] != '?')){
				parts.splice(0,2);
//				console.log("LONG", parts);
				processCommands( parts);
			} else {
			    voiceMessage("Ehi Tuya... ");
			}
			
}  else {
            voiceMessage("Sorry: voice command must start with 'Ehi Tuya'!");
        }
}

function processCommands(parts){
			// escludes extras
             if (['in', 'il', 'a', 'al', 'ad'].includes(parts[0].toLowerCase())){
                  parts.splice(0,1);
			 }
             if (['il','lo','la', 'le', 'a', 'ad', 'ai', 'al', 'all', 'allo', 'alla', 'alle', 'di', 'del', 'della', 'dei','un', 'una', 'con', 'colla'].includes(parts[1].toLowerCase())){
                    parts.splice(1,1);
			 }
// console.log(parts);
            switch (parts[0].toLowerCase()) {
                // here verbs...
            case "esegui":
            case "attiva":
                // 'Hei Tuya. esegui|attiva (il|la|un|una) xxx (xxx) (xxx)' (tap-to-run|RULE)
                // tap to run|RULE name: one, two or three words
                let st = parts[1];
                let s1 = getScene(st);
				let idx = ignoreIndexOf(ruleNames, st);
                if (!(s1) && (idx == -1)) {
                    st += " " + parts[2];
                    s1 = getScene(st);
					idx = ignoreIndexOf(ruleNames, st);
                }
                if (!(s1) && (idx == -1)) {
                    st += " " + parts[3];
                    s1 = getScene(st);
					idx = ignoreIndexOf(ruleNames, st);
                }
                if (s1) {
                    setTimeout(doTTR, 50, s1);
                    voiceMessage("Done: called tap-to-run '" + st + "'.");
				     } else
                if (idx > -1){
					let index = runRule.indexOf(ruleNames[idx]);  // more calls?
                    if (index == -1) {
		             	runRule.push(ruleNames[idx]);  // no, adds
		            }
					voiceMessage("Done: called RULE '" + st + "'.");
					extraRun = true;
					setTimeout(pollingRules, 50);
				} else
                    voiceMessage("Not found tap-to-run|RULE: " + st);
                break;
            case "ritorna":
            case "home":
                // 'Hei Tuya, ritorna'
                // 'Hei Tuya, (ad) home'
                if (document.getElementById("rule-section").style.display == 'block') {
                    setTimeout(toggleRule, 50, false);
                } else
                    if (document.getElementById("tap-section").style.display == 'block') {
                        setTimeout(toggleTap, 50, false);
                    } else
                        beep();
                break;
            case "vai":
                switch (parts[1].toLowerCase()) {
                    // 'Hei Tuya, vai alle regole (RULE page)
                case "regola":
                case "regole":
                    if (categories) {
                        if (document.getElementById("tree-section").style.display == 'block') {
                            setTimeout(toggleRule, 50, false);
                        } else
						    beep();
                     } else
                        voiceMessage("Sorry: must be in EXPERT mode.");
                    break;
                case "scene":
                case "scena":
                    // 'Hei Tuya, vai alle scene' (tap-to-run page)
                    if (document.getElementById("tree-section").style.display == 'block') {
                        setTimeout(toggleTap, 50, false);
                    } else
                        beep();
                    break;
                case "home":
                    // 'Hei Tuya, vai ad home'
                    if (document.getElementById("rule-section").style.display == 'block') {
                        setTimeout(toggleRule, 50, false);
                    } else
                        if (document.getElementById("tap-section").style.display == 'block') {
                            setTimeout(toggleTap, 50, false);
                        } else
                            beep();
                    break;

                } //  end case 'vai'
                break;
			case "basta":
			      if (  ['voce','voice'].includes(parts[1].toLowerCase()) ) {
					 voiceends();  
				  }
				  break;
            case "modo":
                // Hei Tuya, modo ESPERTO'
                  if ( ['expert','esperto'].includes(parts[1].toLowerCase()) ) {
                    if ((!categories) && expertModeEnabled) {
                        expertMode(false);
                        voiceMessage("Done: EXPERT mode attivato");
                    } else {
                        if (categories)
                            voiceMessage("Già in EXPERT mode");
                        else
                            beep();
                    } 					
                    break;
                   }
                // Hei Tuya, in modo UTENTE'
                if ( ['user','utente'].includes(parts[1].toLowerCase()) ) {
                    if (categories) { //i.e EXPERT mode
                        expertMode(false);
                        voiceMessage("Done: USER mode attivato");
                    } else {
                        voiceMessage("Già in USER mode");
                    }
                    break;
                  }
			
				 if ((parts[1].toLowerCase() == 'voce') && (['continuo','continua'].includes(parts[2].toLowerCase()))){
					SpeechRecognitionNeverEnds = true;
					document.getElementById("offbutton").style.display = "inline"; 
					document.getElementById("voicebutton").disabled = true;
		            document.getElementById("offbutton").disabled = false;
                    break;
				 } 
                 if ((parts[1].toLowerCase() == 'voce') && (['a','su'].includes(parts[2].toLowerCase())) && (['richiesta','comando'].includes(parts[3].toLowerCase())) ) {
 					SpeechRecognitionNeverEnds = false;
					document.getElementById("offbutton").style.display = "none"; 
					document.getElementById("voicebutton").disabled = true;
		            break;
				 } 				 
                break;
            default:
                voiceMessage("Sorry: the voice command must contain a known instruction");
            } // end case 'ehi Tuya'
       statusInit = true;
}

// =================================== locals

var statusInit  = true; 
//
function voiceMessage(text) {
    document.getElementById("voice").innerText = text;
}

// ================================== voice startup
var recognition = null;

if (SpeechRecognitionEnabled) {
    try {
        var SpeechRecognition = SpeechRecognition ||
                                webkitSpeechRecognition ||
                                mozSpeechRecognition ||
                                msSpeechRecognition ||
                                oSpeechRecognition;
  // var SpeechGrammarList = SpeechGrammarList || window.webkitSpeechGrammarList
  // var SpeechRecognitionEvent = SpeechRecognitionEvent || webkitSpeechRecognitionEvent

        recognition = new SpeechRecognition();
    } catch (e) {
        console.error(e);
        myMsgBox("Voice Recognition", "This browser does not support speech recognition.\n Continue without the speech facility.");
        document.getElementById("voicediv").style.display = "none";
        document.getElementById("mynetwork").style.height = "86vh";
    }
 if (SpeechRecognitionNeverEnds) {
		   document.getElementById("offbutton").disabled = true;
	   } else {
		   document.getElementById("offbutton").style.display = "none";
	   }
	
} else {  // i.e. user disabled
    document.getElementById("voicediv").style.display = "none";
    document.getElementById("mynetwork").style.height = "86vh";
}

if (recognition)
    console.log('SpeechRecognition enabled.');
// ========================================================
// see https://github.com/TalAter/annyang/blob/master/src/annyang.js
function voicestart() {
	if (recognition){
		recognition.continuous = true;
		try {
			recognition.start();
			console.log('voice started');
		} catch (e) {}
	}
}
function voiceRestart() {
	if (recognition){
		recognition.continuous = true;
		try {
			recognition.start();
     	} catch (e) {}
	}
}
var useroff = false;
function voiceends() {
	if (recognition){
		try {
			useroff = true;
			recognition.abort();
		} catch (e) {}
	}
}
// ========================================== callbacks
if (recognition) {
    recognition.onstart = function () {
       document.getElementById("offbutton").disabled = false;
       document.getElementById("voicebutton").disabled = true;
       voiceMessage('Voice recognition activated. Try speaking into the microphone.');
    }
    recognition.onspeechend = function () {
 	   if (!SpeechRecognitionNeverEnds)
              document.getElementById("voicebutton").disabled = false;
        voiceMessage('You were quiet for a while so voice recognition turned itself off.');
    }
    recognition.onerror = function (event) {
        if (event.error == 'no-speech') {
            voiceMessage('No speech was detected. Try again.');
            recognition.abort();
     	   if (!SpeechRecognitionNeverEnds)
                 document.getElementById("voicebutton").disabled = false;
        };
    }
   recognition.onend = function (event) {
	   if ((SpeechRecognitionNeverEnds) && (!useroff ))
            setTimeout(voiceRestart, 300);
	   if(useroff){
		document.getElementById("voicebutton").disabled = false;
		document.getElementById("offbutton").disabled = true;
		 voiceMessage('Voice recognition turned off.');
		useroff = false;
        };   
	
    }

    recognition.onresult = function (event) {
        // event is a SpeechRecognitionEvent object.
        // It holds all the lines we have captured so far.
        // We only need the current one.
        //      console.log('voice', event);
        var current = event.resultIndex;
        // Get a transcript of what was said.
         var transcript = event.results[current][0].transcript;
        voiceMessage(transcript);
        let parts = (transcript + " ? ? ?").split(' ');
        // cleanup
        while (((parts[0] === '') || (parts[0] === '?')) && (parts.length > 1)) {
            parts.shift();
        }
        if (parts.length < 2)
            return;
        //
		if (statusInit){
            speechEvents(parts);
		} else {
			console.log("SHORTS", parts);

			processCommands(parts);
		}
    }
}

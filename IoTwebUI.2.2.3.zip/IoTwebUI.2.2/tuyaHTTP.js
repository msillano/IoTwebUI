
/*
This file is part of tuyaUIweb project (https://github.com/msillano/TuyaUIweb)
 Send  requests to tuyaCloud REST via HTPP
 sycronous implementation
 IMPORTANT
   This will work in a browser ONLY if CORS is disabled.
   More info in github.
// see https://stackoverflow.com/questions/3102819/disable-same-origin-policy-in-chrome
// see https://stackoverflow.com/questions/7543678/where-to-disable-cross-network-protection-in-opera
------------------------------
License MIT
(C)2024 marco.sillano@gmail.com
version 1.0 15/05/2024
*/

function tuyaHTTP(message)
{
    var xhr = new XMLHttpRequest();
	xhr.onerror = function(e) {
	          console.log("NET ERROR "+e.target.status);
			  throw ("NET ERROR: Unable to connect to Tuya Cloud: Check CORS, credentials.");
              return null;
           	  };
    xhr.open( message.method, message.url, false ); // false for synchronous request
	Object.keys(message.headers).forEach( (key) => {
	   xhr.setRequestHeader(key, message.headers[key]);})
	//xhr.responseType = 'json';
    xhr.send(message.payload||null)
    const  jdata = JSON.parse(xhr.responseText);
//	console.log([message, jdata]);
	if (jdata.success) return jdata.result;
	console.log(["ERROR tuyaHTTP", message, jdata]);
	return null;
}

function restHTTP(url)
{
    var xhr = new XMLHttpRequest();
	xhr.onerror = function(e) {
	          console.log("NET ERROR "+e.target.status);
			  throw ("NET ERROR: Unable to connect to REST.");
              return null;
           	  };
    xhr.open( 'GET', url, false ); // false for synchronous request
	xhr.send(null)
//	console.log(xhr.responseText);
   return xhr.responseText;
}


// tentative
 function tuyaHTTP_Asyn(message) {
  var x = null;


 async function fetchAsync (hd) {
   const response = await fetch(hd.url, {
	   headers: hd.headers })
  .catch(err => console.log(err));
   const data = await response.json();
 // console.log(data);
   if (data.success)
      return (data.result);
   return(null);
  }

// fetchAsync(message).then((res) => {x = res; return(x);});
  fetchAsync(message).then((res) => {console.log(res);});

// catch (e){consle.log(e)};

 //return (x);
}


function THERMOSTAT01(xname = "WEB Thermostat", xroom = "Test", xhome = 'ADMIN') {
	   var sonde = [
        ['Termo letto', 'temp_current', 10],
 //       ['Temperatura letto', 'va_temperature', 1],
    ];

    ADDXDEVICE(xhome, xroom, xname, [{
                code: 'Tswitch',
                value: 1,
            }, {
                code: 'adjust',
                value: 2,
            }, {
                code: 'Hot',
                value: 3,
            },			{
                code: 'Tmode',
                value:4,
            },{
                code: 'Tactual',
                value: 5,
            }, {
                code: 'Ttarget',
                value: 6,
            }, {
                code: 'TimeON',
                value: 7,
            }, {
                code: 'HOTout',
                value:8,
            }, {
                code: 'COLDout',
                value: 9,
            },
        ]);
sleep(10);

    // ====================  EXTRA METADATA for 'Explore scene'
    // (optional) adds 'details.input' and 'details.output' to the x-object
    // for details see https://github.com/msillano/IoTwebUI/blob/main/APP/Scene/LEGGIMI.md#grapho-di-x-device
    //    a) init
 	SETXDEVICESTATUS(xname, 'Tswitch', 11);
	SETXDEVICESTATUS(xname, 'adjust',  12);
 	SETXDEVICESTATUS(xname, 'Hot',     13);
 	SETXDEVICESTATUS(xname, 'Tmode',   14);
 	SETXDEVICESTATUS(xname, 'Tactual', 15);
 	SETXDEVICESTATUS(xname, 'Ttarget', 16);
 	SETXDEVICESTATUS(xname, 'TimeON',  17);
 	SETXDEVICESTATUS(xname, 'HOTout',  18);
 	SETXDEVICESTATUS(xname, 'COLDout', 19);

//sleep(100);

    let xdev = getDeviceFromRef(xname);
 
	if (!xdev.details) { // only at startup
        xdev['details'] = [];
        //   b)here   input data from tuya devices
        // all input thermometers
        for (i = 0; i < sonde.length; i++) {
            xdev.details.push({
                from: {
                    type: "device",
                    id: sonde[i][0],
                },
                action: sonde[i][1] + ".get",
            });
        }
        xdev.details.push({
            action: "<I>week program</I>"
        });
        xdev.details.push({
            from: {
                type: "device",
                id: "HeatingThermostat-vdevo"
            },
            action: "status.get"
        });
        xdev.details.push({
            to: {
                type: "xauto",
                id: "driveOn"
            },
            action: "HOTout=true"
        });
        xdev.details.push({
            to: {
                type: "xauto",
                id: "driveOff"
            },
            action: "HOTout=false"
        });
        xdev.details.push({
            to: {
                type: "xextra",
                id: "UI\\nthermostat01"
            },
            action: "RT data"
        });
        xdev.details.push({
            to: {
                type: "xextra",
                id: "UI\\nthermostat01"
            },
            action: "status"
        });
        xdev.details.push({
            from: {
                type: "xauto",
                id: "driveOff"
            },
            to: {
                type: "tap",
                id: "HOTTURNOFF"
            },
            action: "run"
        });
        xdev.details.push({
            from: {
                type: "xauto",
                id: "driveOn"
            },
            to: {
                type: "tap",
                id: "HOTTURNON"
            },
            action: "run"
        });
    }
    SETXDEVICEONLINE(xname);

    return;
}
// end  THERMOSTAT01 code

// =========== RULEs for THERMOSTAT01:
// 2-A) Copy this 'RULES for THERMOSTAT01'   in the RULE-pad at run time (temporary)
// 2-B) Or copy this 'RULES for THERMOSTAT01' in the 'var usrrules' in the usrrulesXX.X.js file (better - permanent).
/*
THERMOSTAT01();  // runs this every loop, uses default values - see line 29 - required

//   note: the Tuya 'tap-to-run' "HOTTURNON", "HOTTURNOFF", etc.  MUST EXIST !
//   rules for HOT on/off - optional (driveOn, driveOff)
if(GET("WEB Thermostat","HOTout", false)) SCENE("HOTTURNON");
if(GET("WEB Thermostat","HOTout", false)) SCENE("HOTTURNOFF");

//   rules for COLD on/off - optional
if(GET("WEB Thermostat","COLDout", false)) SCENE("COLDTURNON");
if(GET("WEB Thermostat","COLDout", false)) SCENE("COLDTURNOFF");

*/

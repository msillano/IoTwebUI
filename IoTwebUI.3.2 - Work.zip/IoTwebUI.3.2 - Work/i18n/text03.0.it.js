
// ========================================
// Js strings - versione ITALIANO
var IoTlang = "IT";
//
var JsTxt = [];
// === texts in IoTwebUI.html - HTML
JsTxt[1]  = "non attiva.";
JsTxt[2]  = "attiva. Formato ";
JsTxt[3]  = ", intervallo ";
JsTxt[4]  = "Salvataggio file ogni ";
JsTxt[5]  = " ore.";
JsTxt[6]  = "Salvataggio con comando manuale";
JsTxt[7]  = "TAP-TO-RUN";
JsTxt[8]  = "modo ESPERTO";
JsTxt[9]  = "modo UTENTE";
JsTxt[10] = "GRAFO TUYA";
JsTxt[11] = "nuove REGOLE";
JsTxt[12] = "Salva file Datalog";
JsTxt[13] = "Registro Allarmi";
JsTxt[14] = "Ricarica i Device";
JsTxt[15] = "Oggetto-dati in console";
JsTxt[16] = "Salvataggio auto ogni ";
JsTxt[17] = " ore.\n Salvare comunque adesso?";
JsTxt[18] = "Le REGOLE in uso saranno cancellate. \nSi applicheranno le nuove regole con memoria azzerata.";
JsTxt[19] = "WARNING: Test in corso.";
JsTxt[20] = "Le REGOLE attualmente in uso saranno sospese. \n Saranno ripristinate a fine test.\n In caso di errore il test termina automaticamente";
JsTxt[21] = "WARNING: Non in fase di Test.";
JsTxt[22] = "Test terminato dall'utente:\n Ripristino delle REGOLE base.";
JsTxt[23] = "Definizione nuove REGOLE";
JsTxt[24] = "Questa APP legge i dati in polling da Tuya Cloud ogni <span id='aboutSec'>60</span> secondi.";
JsTxt[25] = "DataLog: L'opzione di Export su file locale è <span id='aboutFile'>disattiva.</span>";
JsTxt[26] = "Documentazione nel sito <a href='https://github.com/msillano/IoTwebUI' target='_black'>IoTwebUI</a>.";
JsTxt[27] = "Informazioni";
JsTxt[28] = "Menu";
JsTxt[29] = "OFF";
JsTxt[30] = "chiaro";
JsTxt[31] = "scuro";
JsTxt[32] = "auto";
JsTxt[33] = "nascondi";
JsTxt[34] = "&nbsp;&nbsp;voce";
JsTxt[35] = "Connessione al Cloud...";
JsTxt[36] = "Pulisci";
JsTxt[37] = "Carica";
JsTxt[38] = "Sostituisci";
JsTxt[39] = " Copiare nel file usrrulesX.X.js";
JsTxt[40] = "Esporta";
JsTxt[41] = "Proprietà";
JsTxt[42] = "log +";
JsTxt[43] = "log -";
JsTxt[44] = "esporta";
JsTxt[45] = "cancella";
JsTxt[46] = "allarmi";
JsTxt[47] = "valore";
JsTxt[48] = "valore di test";
JsTxt[49] = "messaggio";
JsTxt[50] = "&lt;testo/URL/Tap-to-run/regola&gt;";
JsTxt[51] = "beep&nbsp;";
JsTxt[52] = "pop&nbsp;";
JsTxt[53] = "suono&nbsp;";
JsTxt[54] = "voce";
JsTxt[55] = "test +";
JsTxt[56] = "test -";
// === texts in tuyauiXX.X - js
JsTxt[57]  = "<BR><BR>&nbsp;&nbsp;&nbsp;<b> ERRORE del TOKEN Tuya</b><BR>&nbsp;&nbsp;&nbsp; Accesso a Tuya fallito. Verificare credenziali e CORS (vedi console...)";
 //   "<BR><BR>&nbsp;&nbsp;&nbsp;<b> TOKEN ERROR </b><BR>&nbsp;&nbsp;&nbsp; Failed Tuya access. Check credentials and CORS (see console...)";

 JsTxt[58]  = "<BR><BR>&nbsp;&nbsp;&nbsp;<b> ERRORE di INIZIALIZZAZIONE </b><BR>&nbsp;&nbsp;&nbsp; vedi console...";
 JsTxt[59]  = "<button onclick='next = true;'> PRONTO - premere per continuare... </button>";
 JsTxt[60]  = "<BR><BR>&nbsp;&nbsp;&nbsp;<b> ERRORE INTERNO </b><BR>&nbsp;&nbsp;&nbsp; vedi console...";
 JsTxt[61]  = "Già selezionato: nulla da fare";
 JsTxt[62]  = "Aggiungere alla lista di Log ";
 JsTxt[63]  = " ?\n nota: in formato CSV, salva l'attuale file e ne inizia uno nuovo.";
 JsTxt[64]  = "Il device non è nella lista di Log: nulla da fare";
 JsTxt[65]  = " Excludere il device ";
 JsTxt[66]  = " dalla lista di Log ?\n  nota: salva l'attuale file CSV e ne inizia uno nuovo.";
 JsTxt[67]  = " dalla lista di Log ? ";
 JsTxt[68]  = "Cancellare tutti i test per il device ";
 JsTxt[69]  = "Aggiungere un nuovo Test di allarme per ";
 JsTxt[70]  = "ERRORE in config.js /n Il codice in 'testList' non può essere processato!";
 JsTxt[71]  = " WARNING: Il nome '"
 JsTxt[72]  = "' non è unico! - Usare invece l'ID";
 JsTxt[73]  = " COPIARE IN config.js DALLA RIGA SEGUENTE ALLA FINE >>>\n\n const testList = \`  ";
 JsTxt[74]  = "ERRORE in config.js /n Il codice in 'logList' non può essere processato!";
 JsTxt[75]  = "ERRORE - device NOT trovato: verificare l'ID/nome del 'device'";
 JsTxt[76]  = "ERRORE - proprietà NOT trovata: verificare il nome dello 'status'";
 JsTxt[77]  = " COPIARE IN config.js DALLA RIGA SEGUENTE ALLA FINE >>>\n\n const logList =  \`  \n";
 // === texts in usrrulesXX.X - js
 JsTxt[78]  = "ERRORE durante il test";
 JsTxt[79]  = " Riga ";
 JsTxt[80]  = ". Test terminato:\n >";
 JsTxt[81]  = "ERRORE nelle REGOLE di base";
 JsTxt[82]  = ". REGOLE disabilitate:\n >";
 // === texts in speechXX.X - js
 JsTxt[83]  = "Ehi Tuya... ";
 JsTxt[84]  = "Un comando vocale deve cominciare con 'Ehi Tuya'!";
 JsTxt[85]  = "Fatto: chiamato tap-to-run '";
 JsTxt[86]  = "Fatto: chiamata REGOLA '";
 JsTxt[87]  = "Non trovato tap-to-run|REGOLA: ";
 JsTxt[88]  = "Attenzione: solo in modo ESPERTO.";
 JsTxt[89]  = "Fatto: attivato modo ESPERTO.";
 JsTxt[90]  = "Attenzione: già in modo ESPERTO";
 JsTxt[91]  = "Fatto: attivato modo UTENTE.";
 JsTxt[92]  = "Attenzione: già in modo UTENTE";
 JsTxt[93]  = "Attenzione: un comando vocale deve contenere un'istruzione nota.";
 JsTxt[94]  = "Voice Recognition";
 JsTxt[95]  = "Questo browser non supporta il riconoscimento vocale.\n Continuare senza i comandi vocali.";
 JsTxt[96]  = "Riconoscimento vocale attivo. Dite qualcosa nel microfono.";
 JsTxt[97]  = "Silenzio prolungato: riconoscimento vocale spento.";
 JsTxt[98]  = "Nessuna voce riconosciuta. Riprovare.";
 JsTxt[99]  = "Riconoscimento vocale disattivo.";

 JsTxt[100] = "device ";

// ========================================

function special_HTML(){
// Tag using predefined ids: mapping messages
 document.getElementById("tap-toggle").innerHTML = JsTxt[7];
 document.getElementById("expert-mode").innerHTML = JsTxt[8];
 document.getElementById("tree-toggle").innerHTML = JsTxt[10];
 document.getElementById("rule-toggle").innerHTML = JsTxt[11];
 document.getElementById("save_log").innerHTML = JsTxt[12];
 document.getElementById("dump_alert").innerHTML = JsTxt[13];
 document.getElementById("exp_tree").innerHTML = JsTxt[14];
 document.getElementById("exp_dump").innerHTML = JsTxt[15];
 document.getElementById("log-export").value = JsTxt[42];
 document.getElementById("log-clear").value = JsTxt[43];
 document.getElementById("log-config").value = JsTxt[44];
 document.getElementById("log-cancel").value = JsTxt[45];
 document.getElementById("limit-value").value = JsTxt[48];
 document.getElementById("w3review").innerHTML = JsTxt[50];
 document.getElementById("lbeep").innerHTML = JsTxt[51];
 document.getElementById("lpopup").innerHTML = JsTxt[52];
 document.getElementById("lsound").innerHTML = JsTxt[53];
 document.getElementById("laudio").innerHTML = JsTxt[54];
 document.getElementById("observe-observe").value = JsTxt[55];
 document.getElementById("observe-clear").value = JsTxt[56];
 document.getElementById("observe-config").value = JsTxt[44];
 document.getElementById("observe-cancel").value = JsTxt[45];
}

var i18l_html =[];
// Tags using "i18l_xx" id: mapping messages
i18l_html[1]  = JsTxt[24];
i18l_html[2]  = JsTxt[25];
i18l_html[3]  = JsTxt[26];
i18l_html[4]  = JsTxt[27];
i18l_html[5]  = JsTxt[28];
i18l_html[6]  = JsTxt[29];
i18l_html[7]  = JsTxt[30];
i18l_html[8]  = JsTxt[31];
i18l_html[9]  = JsTxt[32];
i18l_html[10] = JsTxt[33];
i18l_html[11] = JsTxt[34];
i18l_html[12] = JsTxt[35];
i18l_html[13] = JsTxt[23];
i18l_html[14] = JsTxt[36];
i18l_html[15] = JsTxt[37];
i18l_html[16] = JsTxt[38];
i18l_html[17] = JsTxt[40];
i18l_html[18] = JsTxt[41];
i18l_html[19] = JsTxt[46];
i18l_html[20] = JsTxt[47];
i18l_html[21] = JsTxt[49];

function i18l_html_A(){
// Home page (id auto increment)
 for (var key in i18l_html) {
	 try{
     document.getElementById("i18l_"+key).innerHTML = i18l_html[key];
	 } catch(e) { console.log("error at i ="+ key +"   " +e);}

	}
 }

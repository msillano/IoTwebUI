// ========================================
// Js strings - ENGLISH version
var IoTlang = "EN";
//
var JsTxt = [];
JsTxt[1]  = "not enabled.";
JsTxt[2]  = "enabled. Format ";
JsTxt[3]  = ", sampling interval ";
JsTxt[4]  = "Saving file every ";
JsTxt[5]  = " hours.";
JsTxt[6]  = "Save with manual command";
JsTxt[7]  = "TAP-TO-RUN";
JsTxt[8]  = "EXPERT mode";
JsTxt[9]  = "USER mode";
JsTxt[10] = "TUYA GRAPH";
JsTxt[11] = "new RULES";
JsTxt[12] = "Save Datalog file";
JsTxt[13] = "Alarm Log";
JsTxt[14] = "Reload Devices";
JsTxt[15] = "Data-object in console";
JsTxt[16] = "Auto save every ";
JsTxt[17] = " hours.\nAre you sure you want to save now anyway?";
JsTxt[18] = "The RULES in use will be deleted. \nThe new rules with zero memory will apply.";
JsTxt[19] = "WARNING: Test in progress.";
JsTxt[20] = "The RULES currently in use will be suspended.\n They will be restored at the end of the test.\n In case of error the test ends automatically";
JsTxt[21] = "WARNING: Not in testing.";
JsTxt[22] = "Test terminated by user:\n Restoring basic RULES.";
JsTxt[23] = "Definition of new RULES";
JsTxt[24] = "This APP reads data from Tuya Cloud every <span id='aboutSec'>60</span> seconds.";
JsTxt[25] = "DataLog: The Export to local file option is <span id='aboutFile'>disabled.</span>";
JsTxt[26] = "Documentation on the site <a href='https://github.com/msillano/IoTwebUI' target='_black' >IoTwebUI</a>.";
JsTxt[27] = "Information";
JsTxt[28] = "Menu";
JsTxt[29] = "OFF";
JsTxt[30] = "clear";
JsTxt[31] = "dark";
JsTxt[32] = "auto";
JsTxt[33] = "hide";
JsTxt[34] = "&nbsp;&nbsp;voice";
JsTxt[35] = "Connecting to the Cloud...";
JsTxt[36] = "Clean";
JsTxt[37] = "Load";
JsTxt[38] = "Replace";
JsTxt[39] = " Copy to file usrrulesX.X.js";
JsTxt[40] = "Export";
JsTxt[41] = "Properties";
JsTxt[42] = "log +";
JsTxt[43] = "log -";
JsTxt[44] = "export";
JsTxt[45] = "cancel";
JsTxt[46] = "alart";
JsTxt[47] = "value";
JsTxt[48] = "test value";
JsTxt[49] = "message";
JsTxt[50] = "&lt;text/URL/Tap-to-run/rule&gt;";
JsTxt[51] = "beep&nbsp;";
JsTxt[52] = "pop&nbsp;";
JsTxt[53] = "sound&nbsp;";
JsTxt[54] = "voice";
JsTxt[55] = "test +";
JsTxt[56] = "test -";
// === texts in tuyauiXX.X - js
JsTxt[57] = "<BR><BR>&nbsp;&nbsp;&nbsp;<b> Tuya TOKEN ERROR</b><BR>&nbsp;&nbsp;&nbsp; Login to Tuya failed. Check credentials and CORS (see console ...)";
JsTxt[58] = "<BR><BR>&nbsp;&nbsp;&nbsp;<b> INITIALIZATION ERROR </b><BR>&nbsp;&nbsp;&nbsp; see console...";
JsTxt[59] = "<button onclick='next = true;'> READY - press to continue... </button>";
JsTxt[60] = "<BR><BR>&nbsp;&nbsp;&nbsp;<b> INTERNAL ERROR </b><BR>&nbsp;&nbsp;&nbsp; see console...";
JsTxt[61] = "Already selected: nothing to do";
JsTxt[62] = "Add to log list";
JsTxt[63] = " ?\n note: in CSV format, save the current file and start a new one.";
JsTxt[64] = "The device is not in the Log list: nothing to do";
JsTxt[65] = "Exclude device";
JsTxt[66] = "from the Log list?\nnote: save the current CSV file and start a new one.";
JsTxt[67] = "from the Log list?";
JsTxt[68] = "Delete all tests for the device ";
JsTxt[69] = "Add a new Alarm Test for ";
JsTxt[70] = "ERROR in config.js /n The code in 'testList' could not be processed!";
JsTxt[71] = " WARNING: The name '";
JsTxt[72] = "' is not unique! - Use the ID instead";
JsTxt[73] = " COPY TO config.js FROM THE NEXT LINE TO THE END >>>\n\n const testList = \` ";
JsTxt[74] = "ERROR in config.js /n The code in 'logList' could not be processed!";
JsTxt[75] = "ERROR - device NOT found: check the ID/name of the 'device'";
JsTxt[76] = "ERROR - NOT property found: check the name of the 'status'";
JsTxt[77] = " COPY TO config.js FROM THE NEXT LINE TO THE END >>>\n\n const logList = \` \n";
// === texts in usrrulesXX.X - js
 JsTxt[78] = "ERROR while testing";
 JsTxt[79] = " Row ";
 JsTxt[80] = ". Test finished:\n >";
 JsTxt[81] = "ERROR in the basic RULES";
 JsTxt[82] = ". RULES disabled:\n >";
 // === texts in speechXX.X - js
 JsTxt[83] = "Hey Tuya...";
 JsTxt[84] = "A voice command must begin with 'Hey Tuya'!";
 JsTxt[85] = "Done: called tap-to-run '";
 JsTxt[86] = "Done: calling RULE '";
 JsTxt[87] = "Not found tap-to-run|RULE: ";
 JsTxt[88] = "Attention: only in EXPERT mode.";
 JsTxt[89] = "Done: EXPERT mode activated.";
 JsTxt[90] = "Warning: already in EXPERT mode";
 JsTxt[91] = "Done: USER mode activated.";
 JsTxt[92] = "Warning: already in USER mode";
 JsTxt[93] = "Warning: a voice command must contain a known instruction.";
 JsTxt[94] = "Voice Recognition";
 JsTxt[95] = "This browser does not support speech recognition.\nContinue without voice commands.";
 JsTxt[96] = "Voice recognition enabled. Say something into the microphone.";
 JsTxt[97] = "Prolonged silence: voice recognition off.";
 JsTxt[98] = "No entries recognized. Please try again.";
 JsTxt[99] = "Speech recognition is off.";
 JsTxt[100] = "device ";
 
// ======================================== END TRANSLATION

// HTML set text - 
function special_HTML(){
//HTML TAGs using predefined IDs: mapping messages and updating
document.getElementById("tap-toggle").innerHTML = JsTxt[7];
document.getElementById("expert-mode").innerHTML = JsTxt[8];
document.getElementById("tree-toggle").innerHTML = JsTxt[10];
document.getElementById("rule-toggle").innerHTML = JsTxt[11];
document.getElementById("save_log").innerHTML = JsTxt[12];
document.getElementById("dump_alert").innerHTML = JsTxt[13];
document.getElementById("exp_tree").innerHTML = JsTxt[14];
document.getElementById("exp_dump").innerHTML = JsTxt[15];
document.getElementById("log-export").value = JsTxt[42];
document.getElementById("log-clear").value = JsTxt[43];
document.getElementById("log-config").value = JsTxt[44];
document.getElementById("log-cancel").value = JsTxt[45];
document.getElementById("limit-value").value = JsTxt[48];
document.getElementById("w3review").innerHTML = JsTxt[50];
document.getElementById("lbeep").innerHTML = JsTxt[51];
document.getElementById("lpopup").innerHTML = JsTxt[52];
document.getElementById("lsound").innerHTML = JsTxt[53];
document.getElementById("laudio").innerHTML = JsTxt[54];
document.getElementById("observe-observe").value = JsTxt[55];
document.getElementById("observe-clear").value = JsTxt[56];
document.getElementById("observe-config").value = JsTxt[44];
document.getElementById("observe-cancel").value = JsTxt[45];
}

var i18l_html =[];
//HTML TAGs using "i18l_xx" IDs;  mapping messages
i18l_html[1]  = JsTxt[24];
i18l_html[2]  = JsTxt[25];
i18l_html[3]  = JsTxt[26];
i18l_html[4]  = JsTxt[27];
i18l_html[5]  = JsTxt[28];
i18l_html[6]  = JsTxt[29];
i18l_html[7]  = JsTxt[30];
i18l_html[8]  = JsTxt[31];
i18l_html[9]  = JsTxt[32];
i18l_html[10] = JsTxt[33];
i18l_html[11] = JsTxt[34];
i18l_html[12] = JsTxt[35];
i18l_html[13] = JsTxt[23];
i18l_html[14] = JsTxt[36];
i18l_html[15] = JsTxt[37];
i18l_html[16] = JsTxt[38];
i18l_html[17] = JsTxt[40];
i18l_html[18] = JsTxt[41];
i18l_html[19] = JsTxt[46];
i18l_html[20] = JsTxt[47];
i18l_html[21] = JsTxt[49];

function i18l_html_A(){
// updating TAGs.
 for (var key in i18l_html) {
	 try{
     document.getElementById("i18l_"+key).innerHTML = i18l_html[key];
	 } catch(e) { console.log("error at i ="+ key +"   " +e);}
	 
	}
 }


/*
This file is part of IoTwebUI project (https://github.com/msillano/IoTwebUI)
Contains user data and options
------------------------------
License MIT
(C)2024 marco.sillano@gmail.com
version 2.2 24/06/2024
- added macro SOUND(sounfFile) for music, annonces etc...
- added macro ADDCOUNT(event, restart) as event counter
Dcumentazione italiana: https://github.com/msillano/IoTwebUI/blob/main/LEGGIMI22.md#regole---sintassi
English documentation: https://github.com/msillano/IoTwebUI/blob/main/LEGGIMI22.md#regole---sintassi
 */
// =================================================  USER RULE (OPTIONAL)
// usrRules: are 'js code' fragments
// -----------------------------------------------------------------------
/*
// BASIC EXAMPLES: (this will not work asis with your devices - tested on my net)
// var usrRules = `

// -- various temperature calculations with popup and logging:
// note: define variabiles with 'var', and use alway names beginning with '_' to avoid interferences.
// note: use single line statments, some js functions are not available

var _tf = GET("TF_frigo","va_temperature");
var _tm = AVG(_tf, 6);
var _tr = ROUND( _tm/10,  -1);  // I only get tens
if(TRIGEVERY(8)) POP( "FRIGO", "Frigo: "+ _tf/10 + "°C, media: "+_tm/10 +"°C, round " + _tr +"°C");
DATALOG("frigo.media", _tm/10);

// using _tf, and MACROS: ISCONNECTED() ISCHANGED()  TIME() VOICE() ROUND()
// note: the delay is function of tuya polling interval and device data period. In strings, ROUND can be used to cut a number.

var _annonce = "Alle ore " + TIME(hrs)+" la temperatura è cambiata. Il frigo è a " + ROUND(_tf/10, 1) + " gradi";
if(ISCONNECTED("TF_frigo") && ISCHANGED(_tf)) VOICE(_annonce);

// -- more functions (testing purpose):
// using MACROS: WEEKMAP() BEEP()

if ( WEEKMAP("DLMM-VS")) BEEP();

// using variables, and MACROS: ISTRIGGERL() DAYMAP() SCENA()

var _trgl = ISTRIGGERL(GET("tuya_bridge", "switch_1"));
if(DAYMAP(false,"08:30", true, "22:00") && _trgl) SCENA('sirena2');

// using variables and MACROS: CONFIRMH() ALERTLOG()
// note: this example shows how to debug RULES, using single functions and 'console.log()'
// note: in a if() use comma ',' to execute more than one MACRO

var _doorev = GET("Sensore porta", "doorcontact_state") ;   //event: true if door open
var _doorok = CONFIRMH(_doorev, "01:20");
if(ISTRIGGERH(_doorok)) VOICE("chiudere la porta, grazie"), ALERTLOG("ingresso", "porta aperta") ;
console.log("DOOR", _doorev, _doorok);

//   `;
 */
// ==================== PERMANENT USER RULES
// Since v.2.0: THE 'usrRules' CAN BE CREATED FROM THE APP - EXPERT MODE: COPY IT HERE TO MAKE YOUR CHOICES PERMANENT.  Default for tests:

var usrRules = `
// here your RULEs
// for test: you can delete this
   if (TRIGBYNAME('spegni luce')) VOICE ("Fatto: 'spegni la luce'");
   if (TRIGBYNAME("Pippo")) VOICE ("Trovato Pippo");
   if (TRIGBYNAME("chiamata Pippo")) TRIGRULE("pippo"), VOICE("chiamo Pippo");

`;

// =====================  CUSTOM USER MACROS
// Place here your CUSTOM MACRO or some 'addon' from https://github.com/msillano/IoTwebUI/tree/main/addon
// note: Some hurge RULES can be implemented here, using all MACROs and RULE's instructions.
// Once tested, you can use it as new MACRO or you can minify the code and use it in RULE-pad!
// WARNING: the TRIGBYNAME() MACRO works only on the RULE-pad.
// EXAMPLE: See 'addon' BATTERY01


// =============================== standard MACROS collection
// Do not modify existent MACROS
/// The RULE are called after every Tuya polling: the problem is the MACRO's private data storage when required
// The used solution is a common instance counter (useStore.idx) and a  private data array useStore.val[t].
// The MACRO with storage MUST run at any RULE execution.
// So they NOT work after a IF() - this code can be skipped.
// ===============================
// to define vars for more than a run
function VSET(name, value) {
    useStore.vars[name] = value;
    return;
}

function VGET(name) {
    if (name in useStore.vars)
        return useStore.vars[name];
    return null;
}

// to fire rules by name (vocal)
// use: if ( TRIGBYNAME() ) ... more
// note: name: one...three words, easy (not "test3").
function TRIGBYNAME(name) {
    if (typeof name === "string") {
        let idx = ignoreIndexOf(ruleNames, name); // is a rule ?
        if (idx > -1) {
            let index = runRule.indexOf(ruleNames[idx]) // is to run?
                if (index > -1) {
                    runRule.splice(index, 1); // if found, delete and runs
                    return true //  ok to run
                }
                //		console.log('TRIG', ruleNames, idx, index);
        }
    }
    return false;
}

// Call a rule by name
// if TRIGRULE is before the related TRIGBYNAME(), the rule is called in the same run, else in the next run.
function TRIGRULE(name, parameter = null) {
    if (typeof name === "string") {
        let idx = ignoreIndexOf(ruleNames, name); // is rule ?
        if (idx > -1) {
            let index = runRule.indexOf(ruleNames[idx]) // already to run?
                if (index == -1) {
                    runRule.push(ruleNames[idx]); // add to run
                    _ruleParam = parameter;
                }
        } else
            throw "TRIGRULE: not found RULE '" + name + "'.";
    } else
        throw "TRIGRULE: requires a RULE name.";
}
// true  al passaggio di  condition false => true
function ISTRIGGERH(condition) {
    const t = useStore.idx++;
    if ((condition === null) || (condition === undefined))
        throw "ISTRIGGER: condition is null.";
    if (useStore.val[t] === undefined) {
        useStore.val[t] = !!condition;
		return false;
 //       return !!condition; // first time: return condition
    }
    if ((!useStore.val[t]) && condition) {
        useStore.val[t] = !!condition;
        return true;
    }
    useStore.val[t] = !!condition;
    return false;
}
// true al passaggio true => false
function ISTRIGGERL(condition) {
    return ISTRIGGERH(!condition);
}
// test if 'true' condition is set for more than time ("ss", "mm:ss", "hh:mm:ss")
// then out 'true' until condition is 'true'
function CONFIRMH(condition, time) {
    const f = useStore.idx++;
    if ((condition === null) || (condition === undefined))
        throw "CONFIRM: condition is null";
    if ((!condition) || (useStore.val[f] == undefined)) {
        useStore.val[f] = Infinity;
        return false;
    }
    if (useStore.val[f] == Infinity) {
        const pieces = ("00:00:" + time).split(':');
        let sum = parseInt(pieces[pieces.length - 1]) * 1000;
        sum += parseInt(pieces[pieces.length - 2]) * 60000;
        sum += parseInt(pieces[pieces.length - 3]) * 3600000;
        useStore.val[f] = sum + Date.now() - ((tuyaInterval / 2) * 1000);
        return false;
    } else
        return (Date.now() > useStore.val[f]);
}
// test if 'false' condition is set for more than time ("ss", "mm:ss", "hh:mm:ss")
function CONFIRML(condition, time) {
    return CONFIRMH(!condition, time);
}

// based on polling loop, skyps some runs
// n: loops count, as time <= n x tuyaInterval (note, we can have extra run)
function TRIGEVERY(n) {
    if (isNaN(n))
        throw "TRIGEVERY: parameter must be a number.";
    const e = useStore.idx++;
    if (useStore.val[e] == undefined) {
        useStore.val[e] = 1;
        return (false);
    }
    let tot = 0;
    if (!extraRun) // only loop runs
        tot = ++useStore.val[e];
    if (tot > n) {
        useStore.val[e] = 0;
        return true;
    }
    return false;
}
// returns hh:mm:ss, or mm:ss, or ss, what == hrs  min  sec ISO (symbol, not string).
const ISO = 0;
const sec = 17;
const min = 14;
const hrs = 11;

function TIME(what = 0) {
    if (isNaN(n) || (![0, 17, 14, 11].includes(what)))
        throw "TIME: parameter must be a constant - 0, 17,14,11.";

    let d = new Date();
    d = new Date(d.getTime() - d.getTimezoneOffset() * 60000);
    return d.toISOString().slice(what, 19);
}

// da '00:00' a time1 => val0, da time1 a time2 => val1...dopo timeK => val0
//  time: string like "02:36", crescent values
//  use: as temperature profile, as time limits (true/false), for repetitive tasks etc.
function DAYMAP(val1, time1, val2, time2, ...value_timestr) {
    if ((arguments.length % 2) == 1)
        throw "DAYMAP: arguments must be even.";
    let d = new Date();
    d = new Date(d.getTime() - d.getTimezoneOffset() * 60000);
    let h = d.toISOString().slice(11, 16);
    for (i = 1; i < arguments.length; i += 2) {
        if (arguments[i] > h)
            return arguments[i - 1];
    }
    return (arguments[0])
}
// input: a string 'X-XXX-Y-' starting on Sunday: 'DLMMGVS', '-' return false, else true
// use: condition on weekday
function WEEKMAP(map) {
    if (map.length != 7)
        throw "WEEKMAP: string length must be 7";
    let d = new Date();
    if (map.charAt(d.getDay()) == '-')
        return false;
    return true;
}
// strings of 12 (mesi: 'GFMAMGLASOND' and 31 chars (giorni:  '1234567890123456789012345678901') (any), '-' minds skip.
// Only if today both mounth and day are ('-') returns false, else true
function YEARMAP(mesi, giorni) {
    if ((mesi.length != 12) || (giorni.length != 31))
        throw "YEARMAP: strings length must be 12 and 31";
    let d = new Date();
    if ((mesi.charAt(d.getMonth()) == '-') && (giorni.charAt(d.getDate() - 1) == '-'))
        return false;
    return true;
}
// moving average of the last n values
// n: loops count, as time <= n x tuyaInterval
function AVG(value, n) {
    if (isNaN(n))
        throw "AVG: parameter 'n' must be a number.";
    const a = useStore.idx++;
    if (useStore.val[a] == undefined) {
        useStore.val[a] = [0, value];
        return value.toFixed(2);
    }
    let i = useStore.val[a][0];
    if (!extraRun) // only loop runs
        i = ((useStore.val[a][0] + 1) % n);
    useStore.val[a][0] = i;
    useStore.val[a][i + 1] = value;
    let sum = 0;
    let nval = 0;
    for (k = 1; k <= n; k++) {
        if (useStore.val[a][k] != undefined) {
            sum += useStore.val[a][k];
            nval++;
        }
    }
    return (sum / nval).toFixed(2);
}

// test with hhysteresis
function HYSTERESIS(value, test, delta) {
    if (isNaN(value) || isNaN(test) || isNaN(delta))
        throw "HYSTERESIS: requires three numeric parameters.";
    const h = useStore.idx++;
    if (useStore.val[h] == undefined) {
        useStore.val[h] = (value > test);
        return (value > test);
    }
    let res;
    if (useStore.val[h]) // true
        res = (value > (test - (delta / 2)));
    else // false
        res = (value > (test + (delta / 2)));
    useStore.val[h] = res;
    return (res);
}

// note: not precise in case of extra run ( TRIGBYNAME(), etc.)
// unit: [value]/s
function DERIVATIVE(value) {
    if (isNaN(value))
        throw "DERIVATIVE: requres a numeric value.";
    const d = useStore.idx++;
    if (useStore.val[d] == undefined) {
        useStore.val[d] = {};
        useStore.val[d]["val"] = value;
        useStore.val[d]["time"] = Date.now();
        return 0;
    }
    const now = Date.now();
    let dd = (value - useStore.val[d]["val"]) / ((now - useStore.val[d]["time"]) / 1000);
    useStore.val[d]["val"] = value;
    useStore.val[d]["time"] = now;
    return dd;
}

// unit: [value] * s
function INTEGRAL(value, limit = null) {
    if (isNaN(value))
        throw "INTEGRAL: requres a numeric value.";
    const i = useStore.idx++;
    if (useStore.val[i] === undefined) {
        useStore.val[i] = {};
        useStore.val[i]["sum"] = 0;
        useStore.val[i]["val"] = value;
        useStore.val[i]["time"] = Date.now();
        return 0;
    }
    const now = Date.now();
    useStore.val[i]["sum"] += ((value + useStore.val[i]["val"]) / 2) * ((now - useStore.val[i]["time"]) / 1000);
    useStore.val[i]["val"] = value;
    useStore.val[i]["time"] = now;
    if ((limit != null) && (useStore.val[i]["sum"] >= limit)) {
        useStore.val[i]["sum"] = 0;
    }
    return useStore.val[i]["sum"];
}

// moving MAX of the last n values (better n = logInterval/tuyaInterval)
// n: loops count, as time <= n x tuyaInterval (note: can do extra run)
function MAX(value, n) {
    if (isNaN(value) || isNaN(n))
        throw "MAX: requres two numeric parameters.";
    const m = useStore.idx++;
    if (useStore.val[m] == undefined) {
        useStore.val[m] = [0, value];
        return value;
    }
    let i = useStore.val[m][0];
    if (!extraRun) // only loop runs
        i = ((useStore.val[m][0] + 1) % n);
    useStore.val[m][0] = i;
    useStore.val[m][i + 1] = value;
    let max = value;
    for (k = 1; k <= n; k++) {
        if (useStore.val[m][k] > max) {
            max = useStore.val[m][k];
        }
    }
    return max;
}

// returns true if value is changed - no trigger at start
function TRIGCHANGED(value) {
    const c = useStore.idx++;
    if (useStore.val[c] == undefined) {
        useStore.val[c] = value;
    }
    const old = useStore.val[c];
    useStore.val[c] = value;
    return (old != value);
}

// round a number to pos (decimal) or -pos (before dot), 0 minds integer.
// returns a string.
function ROUND(number, pos) {
    if (isNaN(number) || isNaN(pos))
        throw "ROUND: requres two numeric parameters.";
    let k = Number.parseFloat(number);
    if (pos >= 0)
        return (k.toFixed(pos));
    for (i = 0; pos < i; i--)
        k /= 10;
    k = Number(k.toFixed(0));
    for (j = 0; pos < j; j--)
        k *= 10;
    return k.toString();
}

//  ADDCOUNT (event, mode = null)
// retourns the total only if restart is true
// use:  var _total = ADDCOUNT (event, TRIGEVERY(500));
//       if (_total != null) POP("counter", "total is " + _total);  // e.g. action pop
function ADDCOUNT(event, restart) {
    // 15/06 modifierd
    const a = useStore.idx++;
    if (useStore.val[a] === undefined)
        useStore.val[a] = 0;
    const tot = useStore.val[a];
    if (!extraRun && event)
        useStore.val[a]++;
    if (restart) {
        useStore.val[a] = 0;
        return tot;
    }
    return null;
}

// ===================== IOTwebUI API: access to resources


function ISCONNECTED(device) {
    const dev = getDeviceFromRef(device) || null;
    if (!dev)
        throw "ISCONNECTED: not found device " + device;
    return dev.online;
}

function GET(device, property, strict = true) {
    const dev = getDeviceFromRef(device) || null;
    if (dev){
        const xtatus = dev.status.find(rec => rec.code === property) || null;
        if (xtatus) {
          return (xtatus.value);
          }
    }
    if (!strict)
        return (null);
    throw "GET: not found property: " + property + " in device " + device;
}
// ========================== new 2.2

function GETATTRIBUTE(device, attribute, strict = true) {
    const dev = getDeviceFromRef(device) || null;
    if ((!dev) || (dev[attribute] === undefined)){
        if (!strict)
            return (null);
        throw "GET: not found attribute: " + attribute + " in device " + dev.name;
      }
    return (dev[attribute]);
}

function GETIDLIST(home = null, room = null) {
    return (deviceList(home, room, id = true));
}

function GETHOMELIST() {
  let homes =[];
  Object.keys(tuyaData).forEach((xhome) => {homes.push(tuyaData[xhome].name)});
  return(homes);
}

function ADDXDEVICE(home, room, name, init = [], category = "x-dev") {
    doAddXDevice(home, room, name, init, category);
}

function SETXDEVICESTATUS(device, code, value) {
    addToXStatus(device, code, value);
}

function SETXDEVICEONLINE(device, online = true) {
    const dev = getDeviceFromRef(device) || null;
    if (dev)
     	dev.online  = online;
}



function REFRESH(what = 'rule') {
    if (what == 'rule')
        setTimeout(pollingRules, 60);
    else
        setTimeout(tuyaPolling, 800);
}

// ========= ouptput

// add an user variable (name) and a (value) to datalog file
function DATALOG(name, value) {
    const l = logi++;
    usrLog[l] = [name, value, ruleRow];
}

// sends messages to Alert register (log)
function ALERTLOG(name, message) {
    let d = new Date();
    d = new Date(d.getTime() - d.getTimezoneOffset() * 60000);
    let log = "RULE,   " + d.toISOString().slice(0, 10) + ', ' + d.toISOString().slice(11, 19) + ', ';
    log += name + ', ' + message + ", rule @line " + ruleRow + ", none, usr-defined, ;";
    alertLog.push(log);
}

// to get a short sound, uses soundFile (config.js)
function BEEP() {
    beep();
}

// 14/06 ver 2.1 added: MP3 and WAV suported by all browser
//  see https://www.w3schools.com/html/html5_audio.asp;
function SOUND(soundFile) {
    xsound(soundFile);
}

// message in a po-up window
function POP(device, message) {
    myMsgBox(device, message);
}

// open the URL in the default browser
// target: _self, _blank (default), _parent, _top (see window:open )
function XURL(url, target = '_blank') {
    const w = window.open(url, target);
    // 14/06 ver 2,1 added
    if (!w)
        throw "URL: not open. Enable popups for this APP.";
}

function REST(url) {
    return (restHTTP(url));
}

function RESTJSON(url) {
    return (JSON.parse(restHTTP(url)));
}

// più invii sono accodati, per la lingua: tag 'lang' in HTML, riga 13 file IoTwebUI.html
function VOICE(message) {
    voice(message);
}

function SOUND(soundFile) {
    xsound(soundFile);
}

// simulates the 'tap' action: fires a tap-to-run Tuya
function SCENE(scenaNome) {
    const id = getScene(scenaNome) || null;
    if (id)
        doTTR(id);
    else
        throw "SCENA: not found tap-to-rtun " + scenaNome;
}

// ===================== variables (locales) used by the MACROS
var skipBadRules = false;
var ruleRow = 0;
var testMode = false;
var extraRun = false; // flag for extra Run
//
var runRule = []; // list on names to fire
var ruleNames = []; // list of all RULE
//
var testRules = ''; // storage test (edit) rules
var ruleStore = null; // access point
// for userLog data
var logi = 0; // shared special for LOGDATA
var usrLog = []; // shared special for LOGDATA

var _ruleParam = null; // used by
// MACRO's memories
var baseStore = {
    idx: 0, // store for default RULES
    val: [],
    vars: {},
};
var testStore = {
    idx: 0, // store for test RULES
    val: [],
    vars: {},
}
var useStore = baseStore; // acces point

// public
// ===================== management

function initRules(start = false) {
    if (start) {
        skipBadRules = false;
        // at rule start play
        runRule = [];
        useStore.val = [];
        useStore.vars = {};
        usrLog = [];
        _ruleParam = null;
    }
    // at every run (polling)
    useStore.idx = 0;
    logi = 0;
}

function pollingRules() {
    if (skipBadRules)
        return;
    if (testMode) {
        if (testRules.trim() != '') {
            executeRules(testRules);
            if (runRule.length > 0) {
                extraRun = true;
                executeRules(testRules);
                runRule = [];
            }
        }
    } else {
        if (usrRules.trim() != '') {
            executeRules(usrRules);
            if (runRule.length > 0) {
                extraRun = true;
                executeRules(usrRules);
                runRule = [];
            }

        }
    }
    _ruleParam = null;
    extraRun = false;
}

function executeRules(txt) {
    // reset counters
    //  console.log('runRules ENTRY', txt);
    initRules();
    let dorules = txt.split(/\r\n|[\n\v\f\r\x85\u2028\u2029]/);
    for (let i = 0; i < dorules.length; i++) {
        ruleRow++;
        let aline = dorules[i].trim();
        if ((aline == '') || aline.startsWith('//'))
            continue;
        while (aline.endsWith('\\')) {
            aline = aline.substring(0, aline.length - 1) + dorules[++i].trim();
        }
  //      console.log('processing', aline);
        try {
            eval(aline);
        } catch (e) {
            if (testMode) {
                myMsgBox1(JsTxt[78], JsTxt[79] + (ruleRow + 1) + JsTxt[80] + aline + '<\n' + e + '\n' + e.stack);
                beep();
                console.log(' ERROR in test #' + (ruleRow + 1) + ': RULE test ends.', e, e.stack);
                testMode = false;
                initRules(true);
            } else {
                myMsgBox1(JsTxt[81], JsTxt[79] + (ruleRow + 1) + JsTxt[82] + aline + '<\n' + ((e) ? (e + '\n' + e.stack) : ""));
                console.log(' ERROR in rules #' + (ruleRow + 1) + ': RULE disabled.', e, e.stack);
                skipBadRules = true;
            }
        }
    };
}

function updateRULEnames(rulestxt = usrRules) {
    // extracts names
    const allrules = rulestxt.split(/\r\n|[\n\v\f\r\x85\u2028\u2029]/);
    let names = [];
    allrules.forEach((xline) => {
        let aline = xline.trim();
        if (!((aline == '') || aline.startsWith('//'))) {
            aline = aline.replace(/[^a-zA-Z0-9'"_\-]/g, ' ');
            const parts = aline.split(" ");
            //		 console.log(parts);
            parts.forEach((item, idx) => {
                let xname = '';
                if (item == "TRIGBYNAME") {
                    while (!(parts[idx].startsWith('"') || parts[idx].startsWith("'")))
                        ++idx;
                    xname = parts[idx];
                    while (!(xname.endsWith('"') || xname.endsWith("'")))
                        xname += " " + parts[++idx];
                    names.push(xname.replace(/['"]+/g, '').toLowerCase());
                }
            });
        }
    });
    //	console.log(names);
    return names;
}

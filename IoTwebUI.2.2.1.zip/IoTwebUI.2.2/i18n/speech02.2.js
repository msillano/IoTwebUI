/*
This file is part of IoTwebUI project (https://github.com/msillano/IoTwebUI)
contains two custom callback functions: getIcon(), filterDP()
------------------------------
License MIT
(C)2024 marco.sillano@gmail.com
version 2.1 17/06/2024
 */
 /* Frasi italiane:
 "Hei Tuya. esegui|attiva (il|la|un|...) xxx (del|per!...) (yyy) (di|un|...) (zzz)" (xxx (yyy) (zzz) => Nome di 'tap-to-run'|REGOLA, senza 'particelle')
 "Ehi Tuya, ritorna"| "Ehi Tuya, (ad|...) home"
 "Ehi Tuya, vai (alle|...) REGOLE"
 "Ehi Tuya, vai (alle|...) SCENE"
 "Ehi Tuya, vai (ad|..) home"
 "Ehi Tuya, basta (colla|...) voce"
 "Ehi Tuya, (in|...) modo ESPERTO"
 "Ehi Tuya, (in|...) modo UTENTE"
 "Ehi Tuya, (in|...) modo VOCE continua"
 "Ehi Tuya, (in|...) modo VOCE (a|su|...) richiesta|comando"

 Nota. L'uso di 'particelle' come (del|al|...) è facoltativo. L'obiettivo è avere frasi che abbiano senso e aumentare il riconoscimento da parte del motore SpeechRecognition.
 */
// ============ local functions	(CUSTOMIZATION optional)
	 let particelle = ['il', 'lo', 'la', 'le', 'i', 'gli', 'un', 'uno', 'una', 'a', 'ad', 'ai', 'al', 'all', 'allo', 'alla', 'alle', 'agli', 'da', 'dal', 'dallo', 'dalla', 'dalle', 'dai', 'dagli', 'di', 'del', 'dello', 'della', 'delle', 'dei', 'degli', 'con', 'col', 'coi', 'colla', 'in', 'nel', 'nello','nella', 'nei', 'negli', 'nelle', 'su', 'sul', 'sui', 'sullo', 'sulla', 'sulle', 'sugli', 'per', 'tra', 'fra'];

// 
function speechEvents(parts) {
//  console.log('SPEECH parts', parts);
/*
// REGOLE usate per prove:
   if (TRIGBYNAME('spegni luce')) VOICE ("Fatto: 'spegni la luce'");
   if (TRIGBYNAME("Pippo")) VOICE ("Trovato Pippo");
   if (TRIGBYNAME("chiamata Pippo")) TRIGRULE("pippo"), VOICE("chiamo Pippo");
*/
    if (['e', 'ok', 'ehi', 'ehy'].includes(parts[0].toLowerCase()))
        if (['tuya', 'tuia', 'giulia', 'julia'].includes(parts[1].toLowerCase())) {
			statusInit = false;
			if ((parts.length > 2) && (parts[2] != '?')){
				parts.splice(0,2);
//				console.log("LONG", parts);
				processCommands( parts);
			} else {
			    voiceMessage(JsTxt[83]);
			}
			
}  else {
            voiceMessage( JsTxt[84]);
        }
}

function processCommands(parts){
	    //   [Hei Tuya,]  (il|...) AAAA (di|del|...) BBBB
		//   diventa: AAAA BBBB
		//   (il|...): vedi array 'particelle'.	 
              if (particelle.includes(parts[0].toLowerCase())){
                  parts.splice(0,1);
			 }
             if (particelle.includes(parts[1].toLowerCase())){
                    parts.splice(1,1);
			 }
// console.log(parts);
            switch (parts[0].toLowerCase()) {
                // here verbs...
            case "esegui":
            case "attiva":
                // 'Hei Tuya. esegui|attiva (il|la|un|una) xxx (xxx) (xxx)' (tap-to-run|RULE)
                // tap to run|RULE name: one, two or three words
                let st = parts[1];
                let s1 = getScene(st);
				let idx = ignoreIndexOf(ruleNames, st);
                if (!(s1) && (idx == -1)) {
					if (particelle.includes(parts[2].toLowerCase())){
						parts.splice(2,1);
						}
                    st += " " + parts[2];
                    s1 = getScene(st);
					idx = ignoreIndexOf(ruleNames, st);
                }
                if (!(s1) && (idx == -1)) {
				   if (particelle.includes(parts[3].toLowerCase())){
						parts.splice(3,1);
						}
                    st += " " + parts[3];
                    s1 = getScene(st);
					idx = ignoreIndexOf(ruleNames, st);
                }
                if (s1) {
                    setTimeout(doTTR, 50, s1);
                    voiceMessage( JsTxt[85] + st + "'.");
				     } else
                if (idx > -1){
					let index = runRule.indexOf(ruleNames[idx]);  // more calls?
                    if (index == -1) {
		             	runRule.push(ruleNames[idx]);  // no, adds
		            }
					voiceMessage( JsTxt[86] + st + "'.");
					extraRun = true;
					setTimeout(pollingRules, 50);
				} else
                    voiceMessage(JsTxt[87] + st);
                break;
            case "ritorna":
            case "home":
                // 'Hei Tuya, ritorna'
                // 'Hei Tuya, (ad) home'
                if (document.getElementById("rule-section").style.display == 'block') {
                    setTimeout(toggleRule, 50, false);
                } else
                    if (document.getElementById("tap-section").style.display == 'block') {
                        setTimeout(toggleTap, 50, false);
                    } else
                        beep();
                break;
            case "vai":
                switch (parts[1].toLowerCase()) {
                    // 'Hei Tuya, vai alle regole (RULE page)
                case "regola":
                case "regole":
                    if (categories) {
                        if (document.getElementById("tree-section").style.display == 'block') {
                            setTimeout(toggleRule, 50, false);
                        } else
						    beep();
                     } else
                        voiceMessage( JsTxt[88]);
                    break;
                case "scene":
                case "scena":
                    // 'Hei Tuya, vai alle scene' (tap-to-run page)
                    if (document.getElementById("tree-section").style.display == 'block') {
                        setTimeout(toggleTap, 50, false);
                    } else
                        beep();
                    break;
                case "home":
                    // 'Hei Tuya, vai ad home'
                    if (document.getElementById("rule-section").style.display == 'block') {
                        setTimeout(toggleRule, 50, false);
                    } else
                        if (document.getElementById("tap-section").style.display == 'block') {
                            setTimeout(toggleTap, 50, false);
                        } else
                            beep();
                    break;

                } //  end case 'vai'
                break;
			case "basta":
			      if (  ['voce','voice'].includes(parts[1].toLowerCase()) ) {
					 voiceends();  
				  }
				  break;
            case "modo":
                // Hei Tuya, modo ESPERTO'
                  if ( ['expert','esperto'].includes(parts[1].toLowerCase()) ) {
                    if ((!categories) && expertModeEnabled) {
                        expertMode(false);
                        voiceMessage(JsTxt[89]);
                    } else {
                        if (categories)
                            voiceMessage(JsTxt[90]);
                        else
                            beep();
                    } 					
                    break;
                   }
                // Hei Tuya, in modo UTENTE'
                if ( ['user','utente'].includes(parts[1].toLowerCase()) ) {
                    if (categories) { //i.e EXPERT mode
                        expertMode(false);
                        voiceMessage(JsTxt[91]);
                    } else {
                        voiceMessage(JsTxt[92]);
                    }
                    break;
                  }
			
				 if ((parts[1].toLowerCase() == 'voce') && (['continuo','continua'].includes(parts[2].toLowerCase()))){
					SpeechRecognitionNeverEnds = true;
					document.getElementById("offbutton").style.display = "inline"; 
					document.getElementById("voicebutton").disabled = true;
		            document.getElementById("offbutton").disabled = false;
                    break;
				 } 
                 if ((parts[1].toLowerCase() == 'voce') && (particelle.includes(parts[2].toLowerCase())) && (['richiesta','comando'].includes(parts[3].toLowerCase())) ) {
 					SpeechRecognitionNeverEnds = false;
					document.getElementById("offbutton").style.display = "none"; 
					document.getElementById("voicebutton").disabled = true;
		            break;
				 } 				 
                break;
            default:
                voiceMessage(JsTxt[93]);
            } // end case 'ehi Tuya'
       statusInit = true;
}

// =================================== locals

var statusInit  = true; 
//
function voiceMessage(text) {
    document.getElementById("voice").innerText = text;
}

// ================================== voice startup
var recognition = null;

if (SpeechRecognitionEnabled) {
    try {
        var SpeechRecognition = SpeechRecognition ||
                                webkitSpeechRecognition ||
                                mozSpeechRecognition ||
                                msSpeechRecognition ||
                                oSpeechRecognition;
  // var SpeechGrammarList = SpeechGrammarList || window.webkitSpeechGrammarList
  // var SpeechRecognitionEvent = SpeechRecognitionEvent || webkitSpeechRecognitionEvent

        recognition = new SpeechRecognition();
    } catch (e) {
        console.error(e);
        myMsgBox(JsTxt[94], JsTxt[95]);
        document.getElementById("voicediv").style.display = "none";
        document.getElementById("mynetwork").style.height = "86vh";
    }
 if (SpeechRecognitionNeverEnds) {
		   document.getElementById("offbutton").disabled = true;
	   } else {
		   document.getElementById("offbutton").style.display = "none";
	   }
	
} else {  // i.e. user disabled
    document.getElementById("voicediv").style.display = "none";
    document.getElementById("mynetwork").style.height = "86vh";
}

if (recognition)
    console.log('SpeechRecognition enabled.');
// ========================================================
// see https://github.com/TalAter/annyang/blob/master/src/annyang.js
function voicestart() {
	if (recognition){
		recognition.continuous = true;
		try {
			recognition.start();
			console.log('voice started');
		} catch (e) {}
	}
}
function voiceRestart() {
	if (recognition){
		recognition.continuous = true;
		try {
			recognition.start();
     	} catch (e) {}
	}
}
var useroff = false;
function voiceends() {
	if (recognition){
		try {
			useroff = true;
			recognition.abort();
		} catch (e) {}
	}
}
// ========================================== callbacks
if (recognition) {
    recognition.onstart = function () {
       document.getElementById("offbutton").disabled = false;
       document.getElementById("voicebutton").disabled = true;
       voiceMessage(JsTxt[96]);
    }
    recognition.onspeechend = function () {
 	   if (!SpeechRecognitionNeverEnds)
              document.getElementById("voicebutton").disabled = false;
        voiceMessage(JsTxt[97]);
    }
    recognition.onerror = function (event) {
        if (event.error == 'no-speech') {
            voiceMessage( JsTxt[98]);
            recognition.abort();
     	   if (!SpeechRecognitionNeverEnds)
                 document.getElementById("voicebutton").disabled = false;
        };
    }
   recognition.onend = function (event) {
	   if ((SpeechRecognitionNeverEnds) && (!useroff ))
            setTimeout(voiceRestart, 300);
	   if(useroff){
		document.getElementById("voicebutton").disabled = false;
		document.getElementById("offbutton").disabled = true;
		 voiceMessage(' JsTxt[99]');
		useroff = false;
        };   
	
    }

    recognition.onresult = function (event) {
        // event is a SpeechRecognitionEvent object.
        // It holds all the lines we have captured so far.
        // We only need the current one.
        //      console.log('voice', event);
        var current = event.resultIndex;
        // Get a transcript of what was said.
         var transcript = event.results[current][0].transcript;
        voiceMessage(transcript);
        let parts = (transcript + " ? ? ?").split(' ');
        // cleanup
        while (((parts[0] === '') || (parts[0] === '?')) && (parts.length > 1)) {
            parts.shift();
        }
        if (parts.length < 2)
            return;
        //
		if (statusInit){
            speechEvents(parts);
		} else {
			console.log("SHORTS", parts);

			processCommands(parts);
		}
    }
}

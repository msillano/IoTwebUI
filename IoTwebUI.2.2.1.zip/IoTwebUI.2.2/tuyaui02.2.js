/*
This file is part of IoTwebUI project (https://github.com/msillano/IoTwebUI)
Contains user data and options
------------------------------
License MIT
(C)2024 marco.sillano@gmail.com
version 2.2 28/08/2024
version 2.1 17/06/2024
version 2.0 30/05/2024
 */
 /*
 Data center: 1；
 Max number of devices: 50；
 Max number of controllable devices: 10；
 API call/month: 26,000；  (34/h)
 Message/month: 68,000
*/
// ================ Variables
// default options
// TODO: delete test - bugous
// TODO: rendere + veloce tuyapoll 43 - 670 ms
var options = {
    locale: 'it',
    // CUSTOMIZATION ============== comment/uncomment next line
    //        manipulation: { enabled: true },  // add node, edge
    interaction: {
        navigationButtons: true
    }, // add NAVIGATION BUTTONS
    // CUSTOMIZATION ends
    nodes: {
        icon: {
            face: 'FontAwesome',
            size: 50,
        }, // prepara per usare icone FontAwesome
        shape: "icon",
    },
};
// stores info about on/OFF alerts
var alertLog = [];
// deviceid:{home, device_name, device_id,  status_name, status_idx, ok, remark, date, time, value }
var logListO = [];
// test: linked list as array
var testItems = [];
//  list of actions, temporary
var alerts = [];
// new date functions
// see https://discourse.nodered.org/t/node-red-filename-timestamp/22915
Date.prototype.pad2 = function (n) {
    return (n < 10 ? '0' : '') + n;
}
Date.prototype.yyyymmdd = function () {
    return this.getFullYear() + this.pad2(this.getMonth() + 1) + this.pad2(this.getDate());
};

Date.prototype.yyyymmddThhmmss = function () {
    return "D" + this.yyyymmdd() + "T" + this.pad2(this.getHours()) + this.pad2(this.getMinutes()) + this.pad2(this.getSeconds());
};

// ================ utilities
function sleep(milliseconds) {
    // from http://www.phpied.com/sleep-in-javascript/)
    var start = new Date().getTime();
    for (var i = 0; i < 1e7; i++) {
        if ((new Date().getTime() - start) > milliseconds) {
            break;
        }
    }
}
// this is an async timeout util
const timeout = async ms => new Promise(res => setTimeout(res, ms));
let next = false; // this is to be changed on user input
let n = 1;

async function waitUserInput() {
    while (next === false)
        await timeout(50); // pause script but avoid browser to freeze ;)
    next = false; // reset var
}

function isValidURL(str) {
    var a = document.createElement('a');
    a.href = str;
    return (a.host && a.host != window.location.host);
}

// 14/06 ver 2.1 modified
function beep(fsound = beepFile) {
    //  xsound(beepFile);
    try {
        xsound(fsound);
    } catch (e) {
        if ('speechSynthesis' in window) {
            voice("biip");
        }
    }
    return;
}
// 14/06 ver 2.1 added
function xsound(sfile) {
    var audio = new Audio(sfile);
    audio.play();
    return;
}

function voice(txt) {
    if ('speechSynthesis' in window) {
        const synth = window.speechSynthesis;
        const utterThis = new SpeechSynthesisUtterance(txt);
        synth.speak(utterThis);
    } else {
		throw "voice (speechSynthesis) nont found on this browser.";
	}
    return;
}
//
function getDeviceTotal() {
    var tot = 0;
    Object.keys(tuyaData).forEach((home) => {
        tot += tuyaData[home].devices.length;
    });
    return (tot);
}

// access function, by id or name
function getDeviceFromRef(key) {
	if (tuyaData)
      for (const homeId of Object.keys(tuyaData)) {
         for (const device of tuyaData[homeId].devices) {
            if (device.id === key)
                return (device);
            if (device.name === key)
                return (device);
         };
      };
    return null;
}
// return the number of devices having the same name
function getCountName(name) {
    let count = 0;
    for (const homeId of Object.keys(tuyaData)) {
        tuyaData[homeId].devices.forEach((device) => {
            if (device.name == name)
                count++;
        });
    }
    return count;
}

function ignoreIndexOf(array, searchElement, fromIndex = 0) {
  return array.map(function(value) {
    return value.toLowerCase();
  }).indexOf(searchElement.toLowerCase(), fromIndex);
};

// for put HTML in a vis-network tooltip
// use: title: htmlTitle( "here HTML ");
function htmlTitle(html) {
    const container = document.createElement("div");
    container.innerHTML = html;
    return container;
}
// ====================== myMsgBox0  (as pop-up, single, not modal)
// requires HTLML+CSS msgBox definition (hidden)
var ALcount = 0;
function openWindow(id) {
    "use strict";
    // document.getElementById(id).style.visibility = 'visible';
    document.getElementById(id).style.display = 'block';
}
function closeWindow(id) {
    "use strict";
    // document.getElementById(id).style.visibility = 'hidden';
    document.getElementById(id).style.display = 'none';
    ALcount = 0;
}

function myMsgBox0(TITLE, MESSAGE) {
    "use strict";
    ALcount++;
    document.getElementById("msgBox").innerHTML = '<h2 style="text-align:center; margin-top:0px;"> ALERT#' + ALcount + "&nbsp;&nbsp;" + TITLE + '</h2><hr><p align="center">' + MESSAGE + "</p><center><input type='button' value='close' onclick ='closeWindow(\"msgBox\")'/></center>";
    openWindow("msgBox");
}

function myMsgBox1(TITLE, MESSAGE) {
    // 14/06 ver 2.1 modified
    let w = 400;
    let h = 240;
    let l = Math.floor((screen.width - w) / 2);
    let t = Math.floor((screen.height - h) / 2);
    let stili = "width=" + w + ", height=" + h + ", screenY=" + t + ", screenX=" + l + ", popup, status=no, menubar=no, toolbar=no, location=no";
    let testo = window.open("#", "", stili);
    // 14/06 ver 2.1 added
    if (testo) {
        testo.resizeTo(w, h);
        testo.document.write("<html>");
        testo.document.write("<head>");
        testo.document.write("<title>" + TITLE + "</title>");
        testo.document.write("<basefont size=2 face=Tahoma>");
        testo.document.write("</head>");
        testo.document.write("<body topmargin=30>");
        testo.document.write('<h2 style="text-align:center; margin-top:0px;"> ALERT&nbsp;&nbsp;' + TITLE + '</h2><hr><p align="center">' + MESSAGE + "</p><center></center>");
        testo.document.write("</body>");
        testo.document.write("</html>");
    } else {
        //		     throw "POPUP: not open. Enable popups for this APP.";
        myMsgBox0(TITLE, MESSAGE);
    }
}
/*

var _t = ADDCOUNT(true, EVERY(4));
if (_t > 0) POP("Count", "total "+ _t);
console.log( _t);
 */
// -------------- selector
// preferred solution:
// myMsgBox0 pop-up HTML standard modeless in application window, singleton, but with counter
// myMsgBox1 pop-up HTML in a new window, standard modeless, works iconized, many instances
function myMsgBox(TITLE, MESSAGE) {
    myMsgBox1(TITLE, MESSAGE)
};

// window for text copy
function autoPopup(title, text) {
    // 14/06 ver 2.1 modified
    let stili = "top=10, left=10, width=400, height=80, status=no, menubar=no, toolbar=no, location=no";
    let testo = window.open("", "", stili);
    // 14/06 ver 2.1 added
    if (testo) {
        testo.document.write("<html>");
        testo.document.write("<head>");
        testo.document.write("<title>" + title + "</title>");
        testo.document.write("<basefont size=2 face=Tahoma>");
        testo.document.write("</head>");
        testo.document.write("<body topmargin=30> <pre>");
        testo.document.write(text);
        testo.document.write("</pre></body>");
        testo.document.write("</html>");
    } else {
        throw "URL: not open. Enable popups for this APP.";
    }
}

// ================  tuya-vis network
// auto token update functions
function doRefresh() {
    setTimeout(doRefresh, getCldRefreshToken());
    const tokT = new Date(token.expire_time * 1000).toISOString().slice(11, 19);
    console.log("*** token expires in " + tokT);
}

// main function
function driver() {
	// required to do all HTML update (i18l)
   setTimeout(driver2, 200);
}

async function driver2() {

    // ================= startup + tests
   // first tuya cloud connection to get start TOKEN
    try {
        setTimeout(doRefresh, getCldToken());
    } catch (e) {};
    // ERROR no token: EXIT message!
    if (token == null) {
        console.log("ERROR: no token. Check credentials and CORS");
        document.getElementById('mynetwork').innerHTML = JsTxt[57];
        throw 'TOKEN FATAL ERROR';
    }

    try {

        // Token OK: continue console update
        const tokT = new Date(token.expire_time * 1000).toISOString().slice(11, 19);
        console.log("- TOKEN expires in " + tokT);
        // look&feel user options (in config)
        console.log('IoTwebUI init - tuyaInterval: ' + tuyaInterval + (datalog ? 's, logInterval: ' + logInterval + 's' : 's, no logging'));

        // da config to options
        options['interaction'] = {
            navigationButtons: buttonsInteraction
        };
        //

        tuyaDataInizialize(); // step1
        dataProcessing(); // step2
        // tap to run
        initTapToRun();
        setupTTPpage();
		ruleNames = updateRULEnames();
        addRULEbuttons(ruleNames);

    } catch (e) {
        // ISSUE2
        //   console.log("INIT ERROR " +e);
        console.log("INIT ERROR " + e, e.stack);
        document.getElementById('mynetwork').innerHTML = JsTxt[58];
        throw 'INIT FATAL ERROR';
    }

    try {
        // user pause
        document.getElementById('wait').innerHTML = JsTxt[59];

        await waitUserInput();
	        //
        drawFontAwesome4();
        setInterval(tuyaPolling, tuyaInterval * 1000); // starts loop tuyaPolling
        //	 run starts
        setTimeout(tuyaPolling, 300);
		//
		document.getElementById("navbarButton").disabled = false;
        // services after
        readTests();
        if (datalog) {
            setTimeout(doInitLog, 1200);
        }

    } catch (e) {
        // ISSUE2
        //    console.log("RUN ERROR" + e);
        console.log("RUN ERROR" + e, e.stack);
        document.getElementById('mynetwork').innerHTML = JsTxt[60];
            "<BR><BR>&nbsp;&nbsp;&nbsp;<b> RUN ERROR </b><BR>&nbsp;&nbsp;&nbsp; see console...";
        throw 'RUN FATAL ERROR';
    }
}
// ====== vis-network EXPERT user interaction
function clickNode(nodeId) {

    if (!categories)
        return; // not expert mode
    if (nodeId === undefined)
        return;
    // ============ update pop-up data viariables
    let d = getDeviceFromRef(nodeId);
    //   console.log("IN CLICK", nodeId, d);
    if (!d)
        return // node NOT device
        //
        pop_device = d;
    // set elements
    document.getElementById("node-operation").innerText = d.name + " (" + d['is-a'] + ")";
    let i = 1;
    let options = "";
    d.status.forEach(item => {
        options += "<option" + ((i++ == 1) ? " selected=\'selected\'" : "") + " value=\'";
        options += item.code + "\'>" + item.code + " (" + item.value + ")" + "</option> \n";
    });
    if (!options) {
        options = "<option value=\'none\'>none</option>";
    }
    document.getElementById("property").innerHTML = options;
    document.getElementById("log-clear").disabled = !isLogged(d);
    document.getElementById("w3review").value =  JsTxt[100] + d.name+":";

    document.getElementById("equal").checked = true;
    let e = document.getElementById("property");
    document.getElementById("log-export").disabled = (e.options[e.selectedIndex].value == 'none');
    document.getElementById("observe-clear").disabled = (isAlert(pop_device) == 0);

    document.getElementById("node-popUp").style.display = "block"; //'none'"block"
};
// ======= more user interactions EXPERT mode

function log_add() {
    let e = document.getElementById("property");
    let use_property = e.options[e.selectedIndex].value;
    if (use_property == 'none')
        return;
    if (isLogged(pop_device, use_property)) {
        alert( JsTxt[61]);
        return;
    }
    if (confirm(JsTxt[62] + pop_device.name + "." + use_property + JsTxt[63])) {
        if (logFormat === 'CSV')
            saveDataLog();

        let item = {
            home: tuyaData[pop_device.owner_id].name,
            device_id: pop_device.id,
            device_name: pop_device.name,
            status_name: use_property,
            status_idx: e.selectedIndex,
            remark: 'NEW: user added.',
            ok: true
        };
        logListO[pop_device.id + "_" + e.selectedIndex] = item;

        if (logFormat === 'CSV')
            initDataLog();

        nodesVis.update([{
                    id: pop_device.id,
                    title: deviceTooltip(pop_device)
                }
            ]);
        document.getElementById("log-clear").disabled = !isLogged(pop_device);
        console.log(logListO);
    }
}

// botton logging EXCLUDE (CLEAR) for pop_device
function log_clear() {
    if (!isLogged(pop_device)) {
        alert( JsTxt[64]);
        return;
    }

    if (logFormat == 'CSV') {
        if (confirm( JsTxt[65] + pop_device.name +  JsTxt[66])) {
            saveDataLog();
            console.log('user action; delete log for ' + pop_device.name);
            Object.keys(logListO).forEach((i) => {
                if (logListO[i].device_id == pop_device.id)
                    delete logListO[i];
            });
            //			console.log(logListO);
            initDataLog();
            nodesVis.update([{
                        id: pop_device.id,
                        title: deviceTooltip(pop_device)
                    }
                ]);
            document.getElementById("log-clear").disabled = !isLogged(pop_device);
        }
    } else {
        if (confirm( JsTxt[65] + pop_device.name +  JsTxt[67])) {
            console.log('user action: delete log for ' + pop_device.name);
            Object.keys(logListO).forEach((i) => {
                if (logListO[i].device_id == pop_device.id)
                    delete logListO[i];
            });
            ///			console.log(logListO);
            nodesVis.update([{
                        id: pop_device.id,
                        title: deviceTooltip(pop_device)
                    }
                ]);
            document.getElementById("log-clear").disabled = !isLogged(pop_device);
        }
    }
}

//=== VIS builds the full tuyaDATA structure from zero in global tuyaData
function tuyaDataInizialize() {
    tuyaData = {};
    const x = callAPI('GET', "/v2.0/cloud/space/child");
//	console.log("API spaces", x);
    // TODO catch null x - ISSUE12
    if  ( (x == null)||(x.data.length == 0)) {
               console.log(" ERROR : Check the 'data_center' in 'config.js' file !");
               throw " ERROR: no data from Tuya: maybe bad 'data_center' ";
         }
     x.data.forEach((home, idh) => {
        if (home) {
            sleep(20);
            let h = callAPI('GET', "/v1.0/homes/" + home) || {};
	//	    console.log("API home", h);
             tuyaData[home] = h;
            // ISSUE2
            if (!h.name)
                h.name = 'HOME';
            h['rooms'] = [];
            h['devices'] = [];
            h['device_map'] = [];
            sleep(50);
            const d = callAPI('GET', "/v1.0/homes/" + home + "/devices");
  //   		console.log("API devices", d);
            if (d && d[0]) {
                h['devices'] = d;
                // V12
                d.forEach((device) => {
                    h['device_map'][device.id.toString()] = home.toString();
                    device['test'] = null; // new field mandatory
                });
               }

            // ======= now rooms
            sleep(50);
            const r = callAPI('GET', "/v1.0/homes/" + home + "/rooms");
 //  	    	console.log("API rooms", r);
             //ISSUE2
            if (r && r.rooms) {
                h.rooms = r.rooms;
                //			  if (r.rooms){
                r.rooms.forEach((room) => {
                    //	  GET: /v1.0/homes/{home_id}/rooms/{room_id}/devices
                    sleep(50);
                    const d = callAPI('GET', "/v1.0/homes/" + home + "/rooms/" + room.room_id + "/devices");
//			     	console.log("API rooms-device", d);

                    if (d) {
                        d.forEach((device) => {
                            h['device_map'][device.id.toString()] = room.room_id.toString();
                        });
                    }
                });
            }
        }
    }); // for home
}
// ========== NODE structure for vis-network
function deviceTooltip(device) {
	   return (htmlTitle(HTMLTooltip(device)));

}

function HTMLTooltip(device){
    // the 'device.status'is a sub-set of device properties
    // this data are used by main device page in SmartLife.
    // 'status'do not contains configuration or setup info.
    var status = {};
    device.status.forEach((rec) => {
        status[rec.code] = rec.value;
    });
    if (Object.keys(status).length < 1)
        status = {
            status: 'none'
        };
    status = filterDP(device, status);
    // V12	  adds isa, id, key
    if (categories) {
        status['::::::'] = " expert::::::";
        if (device && device["is-a"]) {
            status['is-a'] = device["is-a"];
        }
        // extension for ID & key (expert mode)
        if (device && device.id)
            status['id'] = device.id;
        if (device && device.local_key)
            status['key'] = device.local_key;
    }
    //
    let datastr = " " + JSON.stringify(status, null, '\t');
    // string cosmetics:
    let datastr0 = (datastr.replace(/[,]/g, '').slice(2).slice(0, -2).split('"').join(''));

    //V13
    const i1on = '<i class="fa fa-spinner fa-spin" style="color:green" ></i>&nbsp;';
    const i1off = '<i class="fa fa-database" style="color:LightGrey" ></i>&nbsp;';
    //
    const i22on = '<i class="fa fa-exclamation-triangle" style="color:red" ></i>&nbsp;';
    const i21test = '<i class="fa fa-eye" style="color:blue" ></i>&nbsp;';
    //   const i20none = '<i class="fa fa-check" style="color:DGray"></i>&nbsp;';
    const i20none = '&nbsp;&nbsp;&nbsp;&nbsp;';
    let tipstr = "";
    let ico = true;

    Object.keys(status).forEach((item, sidx) => {
        if (item.startsWith(':::')) {
            ico = false;
            tipstr += '____________________________ <BR>';
        } else {
            let inf = "";
            if (ico) {
                check = isAlert(device, item);
                if ((check == 2) && testAlert) {
                    switch (testAlert.condition) {
                    case 'lst':
                        inf = " (<" + testAlert.value + ")";
                        break;
                    case 'equ':
                        inf = " (=" + testAlert.value + ")";
                        break;
                    case 'grt':
                        inf = " (>" + testAlert.value + ")";
                    }
                }
                tipstr += (check == 0) ? i20none : ((check == 1) ? i21test : i22on);
                //
                tipstr += isLogged(device, item) ? i1on : i1off;
            }
            tipstr += item + ': ' + status[item] + inf + '<BR>';
        }
    });
    //	 console.log(status, tipstr);
    return (tipstr);
}

function createNode(item, type = 'device') {
    // note on nodes:
    // label (visible, is user name or product name
    // id, internal VIS use, is 100/res_id/device_id
    // title: ASCII TXT for tooltip, customizable, see filterDP: usually device status data
    // icon: customizable as glifo and color, see getIcon()
    let n = {};
    if (type == 'root') {
        // only one, added root node.
        n['label'] = "";
        n['id'] = 100;
        n['icon'] = getIcon(null, type);
        n['title'] = "devices: " + getDeviceTotal();
        n['level'] = 0;
        return (n);
    }
    if (type == 'home') {
        // node for Tuya home (space)
        n['label'] = item.name;
        //       n['font'] = "22px arial var(--bs-primary-text-emphasis)";  // cambia colore col click
        n['font'] = "22px arial SlateGray";
        n['id'] = item.home_id;
        n['icon'] = getIcon(null, type);
        n['title'] = "devices: " + item.devices.length + '\n' + item.geo_name;
        n['level'] = 1;
        return (n);
    }
    if (type == 'room') {
        // node for Tuya room
        n['label'] = item.name;
        n['font'] = "20px arial SlateGray";
        n['id'] = item.room_id;
        n['icon'] = getIcon(null, type);
        n['level'] = 2;
        return (n);
    }
    if (type == 'device') {
        // node for all devices
        n['label'] = item.name || item.product_name;
        n['font'] = "16px arial SlateGray";
        n['id'] = item.id,
        n['icon'] = getIcon(item, type, item.online);
        n['title'] = deviceTooltip(item);
        n['level'] = 3;
        return (n);
    }
    if (type == 'x-device') {
        // node for x-devices
        n['label'] = item.name || item.product_name;
        n['font'] = "16px arial SlateGray";
        n['id'] = item.id,
        n['icon'] = getIcon(item, type, item.online);
        n['title'] = deviceTooltip(item);
        n['level'] = 3;
        return (n);
    }
   if (type == 'virtual') {
        // node for x-devices
        n['label'] = item.name || item.product_name;
        n['font'] = "16px arial SlateGray";
        n['id'] = item.id,
        n['icon'] = getIcon(item, type);
        n['title'] = deviceTooltip(item);
        n['level'] = 3;
        return (n);
    }


}

function dataProcessing() {
    // processes the full tuyaData structure.
    // result: the nodes[] and edges[] ready for VIS
    nodes = [];
    edges = [];
    nodes.push(createNode({}, 'root'));
    // homes
    Object.keys(tuyaData).forEach((home) => {
        // OPTION: room exclude
        if (!(exclude_home.includes(home) || exclude_home.includes(tuyaData[home].name))) {
            nodes.push(createNode(tuyaData[home], 'home'));
            edges.push({
                from: '100',
                to: home,
                value: 1
            });
            // ---- rooms
            tuyaData[home].rooms.forEach((room) => {
                nodes.push(createNode(room, 'room'));
                edges.push({
                    from: home,
                    to: room.room_id,
                    value: 1
                });
            });
            // ---- devices
            tuyaData[home].devices.forEach((device) => {
           // push node
				if (device.id.startsWith('x-')){
					  nodes.push(createNode(device, 'x-device'));
				} else 	if (device.id.startsWith('vdev')){
					  nodes.push(createNode(device, 'virtual'));
				} else
                      nodes.push(createNode(device));
		    // push edge
				let edge = {
				         from: tuyaData[home]['device_map'][device.id],
				         to: device.id };

				if (device.id.startsWith("vdev") || device.id.startsWith("x-"))
                	edge['color'] = {color: "black"};
				else if (device.sub) // RED color if SUB device (not WiFi)
					edge['color'] = {color: "red"};

				edges.push(edge);
              });
        } //exclude
    });
}

// MENU BUTTON: user REFRESH network from Tuya Cloud
function refreshALL() {
    // test only
    console.log('User action: reload from Tuya cloud ');
    tuyaDataInizialize(); // step1
    dataProcessing(); // step2
    nodesVis = new vis.DataSet(nodes);
    edgesVis = new vis.DataSet(edges);
    const data = {
        nodes: nodesVis,
        edges: edgesVis,
    };
    const container = document.getElementById("mynetwork");
    network = new vis.Network(container, data, options);
}

// ========== Tuya Cloud polling

function tuyaPolling() {
    // updates data structures
    // this function is cut in many steps (poll1Step, Polling2, poll2Step), to reduce the required time
    // Using 2 rooms, 63 devices: 2 'Violation' of 120-200 ms (for sync GET, function of Net speed).
    console.log(' Tuya polling @' + (new Date().toLocaleTimeString()));
    Object.keys(tuyaData).forEach((home) => {
        // OPTION: room exclude
        if (!(exclude_home.includes(home) || exclude_home.includes(tuyaData[home].name))) {
            setTimeout(tuyaPoll1Step, 100, home);
        }
    });
    setTimeout(tuyaPolling2, 300);
}

function tuyaPoll1Step(home) {
    const d = callAPI('GET', "/v1.0/homes/" + home + "/devices");
    if (d && d[0]) {
        d.forEach((device) => {
            device['test'] = null;
            device['result'] = 0;
            }); // mandatory
        // copy test value from old to neuw
        let observed = tuyaData[home]['devices'].filter((element) => (element.test !== null));
        observed.forEach((olddev) => {
            const newdev = d.find((element) => element.id == olddev.id);
            if (newdev) {
                newdev.test = olddev.test;
                verifyLimits(newdev);
                }
            });
		//  saves x-device
        let customDevices = tuyaData[home]['devices'].filter((element) => (element.id.startsWith('x-')));
        tuyaData[home]['devices'] = [...customDevices,...d];
        }
}

function tuyaPolling2() {
    // upadetes front end
    Object.keys(tuyaData).forEach((home) => {
        // OPTION: room exclude
        if (!(exclude_home.includes(home) || exclude_home.includes(tuyaData[home].name))) {
            setTimeout(executePoll2Step, 50, home);
        }
    });
    // final
    setTimeout(executeAlerts, 200);
    setTimeout(pollingRules, 400);
}

function executePoll2Step(home) {
    tuyaData[home]['devices'].forEach((device) => { // update new
        if (categories && device.category) { // i.e. EXPERT mode
            let cat = categories.find((element) => element.code == device.category);
            if (cat && cat.name) {
                device['is-a'] = cat.name; // updates is-a
            }
        }
        // updates icon & tooltip
        let x = isAlert(device); // 0 - no, 1: observe, 2: trigger ON
        if (x > 1) {
            nodesVis.update([{
                        id: device.id,
                        icon: alertIcon,
                        title: deviceTooltip(device)
                    }
                ]);
        } else {
			let aicon = null;
			if (device.id.startsWith('vdev'))
				aicon = getIcon(device, 'virtual', true);
    	else if (device.id.startsWith('x-'))
				aicon = getIcon(device, 'x-device', device.online);
  		else
				aicon = getIcon(device, 'device', device.online);
            nodesVis.update([{
                        id: device.id,
						icon: aicon,
                        title: deviceTooltip(device)
                    }
                ]);
        }
    });
}

// MENU BUTTON: user SAVE tuyalog file
function userLog() {
    if (datalog) {
        console.log('User action: sending ' + saveDataLog() + ' file');
        initDataLog();
    }
}

// ========== BUILDS vis-network
// standard VIS stuff to create network
// running forever
function drawFontAwesome4() {
    // prepares the arguments
    const container = document.getElementById("mynetwork");
    nodesVis = new vis.DataSet(nodes);
    edgesVis = new vis.DataSet(edges);
    var data = {
        nodes: nodesVis,
        edges: edgesVis,
    };
    // grants font preload
    if (document.fonts) {
        // Decent browsers: Make sure the fonts are loaded.
        document.fonts
        .load('normal normal 400 24px / 1 "FontAwesome" ')
        .catch(console.error.bind(console, "Failed to load Font Awesome 4."))
        .then(function () {
            // create a network
            network = new vis.Network(container, data, options);

            network.on("click", function (params) {
                clickNode(this.getNodeAt(params.pointer.DOM));
            });
        })
        .catch(
            console.error.bind(
                console,
                "Failed to render the network with Font Awesome 4."));
    } else {
        // IE: Let' s just hope the fonts are loaded(they 're probably not,
        // hence the timeout).
        window.addEventListener("load", function () {
            setTimeout(function () {
                // create a network
                network = new vis.Network(container, data, options);
                network.on("click ", function (params) {
                    clickNode(this.getNodeAt(params.pointer.DOM));
                });
            }, 500);
        });
    };
}

// ========== ALERT TESTS Routine

// does test ACTIONs as required
function executeAlerts() {
    alerts.forEach(id => {
        let test = testItems[id];
        let device = getDeviceFromRef(test.device);
        //      console.log(' ALERT ', test, device);
        // to log register
        let d = new Date();
        d = new Date(d.getTime() - d.getTimezoneOffset() * 60000);
        let inf = '';
        switch (test.condition) {
        case 'lst':
            inf = " (<" + test.value + ")";
            break;
        case 'equ':
            inf = " (=" + test.value + ")";
            break;
        case 'grt':
            inf = " (>" + test.value + ")";
        }
        console.log(' test OK for ' + device.name + '.' + test.status);

        let log = "START, " + d.toISOString().slice(0, 10) + ', ' + d.toISOString().slice(11, 19) + ', ';
        log += device.name + ", " + (test.message || 'start alert') + ", " + device.id + ", " + test.status + ', ';
        log += device.status.find(({
                code
            }) => code === test.status).value + ', ' + inf + ',';
        try {
            if (test.action.includes('beep')) {
                beep();
                log += ' beep'
            }
            // 14/06 ver 2.1 added
            if (test.action.includes('sound')) {
                xsound(test.message);
                log += ' sound';
            } else

                if (isValidURL(test.message)) {
                    let x = window.open(test.message, '_blank');
                    if (x) {
                        log += ' URLOK';
                    } else {
                        console.log(' ERROR: ' + test.message + ' not OPEN');
                        log += ' URLBAD';
                    }

                } else {
                    let id = getScene(test.message);
                    if (id) {
                        doTTR(id);
                        log += ' scene';
                    } else {
           // 19/06 ver 2.1 added
		                let idx = ignoreIndexOf(ruleNames, test.message);  // is rule ?
 						if (idx > -1) {
							let index = runRule.indexOf(ruleNames[idx]); // add to run
                            if (index == -1) {
		                      	runRule.push(ruleNames[idx]);
		                        }
                            log += ' RULE';
                         } else {
								if (test.action.includes('pop')) {
									myMsgBox(device.name, test.message);
									log += ' pop';
								}
								if (test.action.includes('voice')) {
									voice(test.message);
									log += ' voice';
								}
						 }
                    }
                }

            log += ';';
            alertLog.push(log);
            // register ends
        } catch (e) {
            log = 'ERROR: ' + log + ';';
            alertLog.push(log);
            console.log("ACTION ERROR " + e, e.stack);
        }
    });
    alerts = []; // cleanup alerts
}

function verifyLimits(device) {
    // updates test, sets alerts[];
    if (device.test === null)
        return; // no test, nothing to do

    let k = device.test; // first test
    do {
        let test = testItems[k];
        if (!test) {
            console.log('INTERNAL ERROR: not found test #' + k, testItems, device);
            return;
        }
        //       console.log("verifyLimits", device, test);
        let status = device.status.find(rec => rec.code === test.status);
        if (!status)
            return (exit); // missed device status - error in test?
        let res_test = null;
        let D = null;
        let T = null;
        try {
            if (typeof(status.value) == 'boolean') {
                D = status.value;
                T = !((test.value == 'false') || (test.value == 'falso') || (test.value == null));
            } else if ((typeof(status.value) == 'string') && (!isNaN(status.value))) {
                D = Number(status.value);
                T = (typeof(test.value) == 'string') ? Number(test.value) : test.value;
            } else if (typeof(status.value) == 'string') {
                D = status.value;
                T = test.value.toString();
            } else {
                D = status.value;
                T = (typeof(test.value) == 'string') ? Number(test.value) : test.value;
            }
            switch (test.condition) {

            case "grt":
                res_test = (D > T);
                break;
            case "equ":
                res_test = (D == T);
                break;
            case "lst":
                res_test = (D < T);
            }
        } catch (e) {
            console.log("ERROR in user value (" + test.value + ") testing " + device.name + "." + status.code, e, e.stack);
            res_test = false;
        }

        if ((typeof(test.trigger) == 'boolean') && res_test && !test.trigger) {
            if (!(k in alerts))
                alerts.push(k); // save out Trigger(k)
        }
        if ((typeof(test.trigger) == 'boolean') && test.trigger && !res_test) {
            let d = new Date();
            d = new Date(d.getTime() - d.getTimezoneOffset() * 60000);
            let inf = '';
            switch (test.condition) {
            case 'lst':
                inf = " (<" + test.value + ")";
                break;
            case 'equ':
                inf = " (=" + test.value + ")";
                break;
            case 'grt':
                inf = " (>" + test.value + ")";
            }
            let log = "END,   " + d.toISOString().slice(0, 10) + ', ' + d.toISOString().slice(11, 19) + ', ';
            log += device.name + ", Fine allerta, " + device.id + ", " + test.status + ', ';
            log += status.value.toString() + ', ' + inf + ';';
            alertLog.push(log);
        }
        test.trigger = res_test;
        k = test.next; // to next step
    } while (k !== null);
    //   console.log(' ALERTS ', alerts);
    return;
}

var testAlert = null; // used by tooltip
// return 0: none, 1: observed, 2: trigger state
// single device.status or full device (all status[])
// Run this after verifyLimits()
function isAlert(device, status = null) {
    testAlert = null;
    if (device.test === null)
        return 0;
    let on = 1;
    let sta = 0;
    let i = device.test;
    if (status) { //   about single status
        do {
            if (testItems[i].trigger && (status == testItems[i].status)) {
                testAlert = testItems[i];
                on++; // trigger ON
            }
            if (status == testItems[i].status)
                sta++; //  observing OK
            i = testItems[i].next; // for all tests (also multiple)
        } while (i !== null);
        //      console.log(' isAlertONE ', device, testItems[i], on, sta, 0);
        if (on > 1)
            return 2; // trigger ON
        if (sta)
            return 1; //  observed
        return 0; //  single status: also NOT observed
    } else {
        do {
            if (testItems[i].trigger)
                on++; // trigger ON
            i = testItems[i].next;
        } while (i !== null);
        //       console.log(' isAlertALL ', device, testItems[i], on, 1, 0);
        if (on > 1)
            return 2;
        return 1; // device alway observed
    }
}

function appendTest(device, test, tidx) {
    let nowDevice = getDeviceFromRef(device.id);
    test.next = nowDevice.test;
    // note: device (from pop_device) can be old
    //    console.log('Adding NEW ' + tidx + ' at' + test.next, nowDevice, testItems);
    nowDevice.test = tidx;
    device.test = tidx;
    return;
}

function detachTest(device, id) {
    // note: device (from pop_device) can be old
    let nowDevice = getDeviceFromRef(device.id);
    if (nowDevice.test == id) {
        nowDevice[test] = testItems[id].next;
        return true;
    }
    let k = nowDevice.test;
    while ((testItems[k].next !== null) && (testItems[k].next != id))
        k = testItems[k].next;
    if (testItems[k].next == id) {
        testItems[k].next = testItems[id].next;
        return true;
    } else {
        return false;
    }
}

function destroyTests(device) {
    let nowDevice = getDeviceFromRef(device.id);
    if (nowDevice.test === null)
        return;
    //    console.log('ENTRO DEL', nowDevice, testItems);
    if (confirm( JsTxt[68] + pop_device.name + " ?")) {
        // note: device (from pop_device) can be old
        let k = nowDevice.test;
        let candidate = [k];
        while (testItems[k].next !== null) {
            k = testItems[k].next;
            candidate.push(k);
        }
        candidate.forEach((i) => delete testItems[i]);
        nowDevice.test = null;
        device.test = null;
        nodesVis.update([{
                    id: nowDevice.id,
                    title: deviceTooltip(nowDevice)
                }
            ]);
        document.getElementById("observe-clear").disabled = true;
    }
    //    console.log('ESCO DEL', nowDevice, testItems);
    return;
}

function getCondition() {
    var radios = document.getElementsByName('conditionlist');
    for (var i = 0, length = radios.length; i < length; i++) {
        if (radios[i].checked) {
            return radios[i].value;
        }
    }
    return 'equ';
}

function newTest(device) {
    let e = document.getElementById("property");
    if (confirm( JsTxt[69] + pop_device.name + "." + e.options[e.selectedIndex].value + " ?")) {
        //       console.log('ENTRO ADD', device, testItems);
        let test = {
            device: device.id,
            status: e.options[e.selectedIndex].value,
            condition: getCondition(),
            value: document.getElementById('limit-value').value,
            message: document.getElementById('w3review').value,
            action: Array.from(document.querySelectorAll('input[type = "checkbox"]:checked')).map(x => x.value),
            trigger: null,
            next: null,
        };
        let i = testItems.push(test) - 1;
        testItems[i]['idx'] = i;
        appendTest(device, test, i);
        console.log("User action: added test #" + i);
        nodesVis.update([{
                    id: pop_device.id,
                    title: deviceTooltip(pop_device)
                }
            ]);
        //        console.log('ESCO ADD', device, testItems);
        document.getElementById("observe-clear").disabled = false;
    }

    return;
}

function readTests() {
    testItems = []; // initialize
    let testarray = null;
    try {
        if (typeof(testList) == 'string')
            testarray = JSON.parse(testList);
        else if (typeof(testList) == 'object')
            testarray = testList;
        else
            return;
    } catch (e) {
        alert( JsTxt[70]);
        return;
    }
    let warn = 0;
    testarray.forEach((usrtst) => {
        let device = getDeviceFromRef(usrtst.device);
        let n = getCountName(device.name);

        let test = {
            device: device.id,
            status: usrtst.property,
            condition: usrtst.condition,
            value: usrtst.value,
            message: usrtst.message || "",
            action: usrtst.action || [],
            trigger: null,
            next: null,
        };
        // append + update
        let i = testItems.push(test) - 1;
        testItems[i]['idx'] = i;
        appendTest(device, test, i);
        // nodesVis.update([{ id: device.id, title: deviceTooltip(device)}]);
    });
    // console.log(testItems);
}

function dumpTest() {
    var testPrint = [];
    Object.keys(testItems).forEach((dId) => {
        let test = testItems[dId];
        let device = getDeviceFromRef(test.device);
        let n = getCountName(device.name);
        let print = {
            device: (n > 1) ? device.id : device.name,
            property: test.status,
            condition: test.condition,
            value: test.value,
        };
        if ((test.message) && (test.message != ''))
            print['message'] = test.message;
        if (test.action.length)
            print['action'] = test.action;
        if (n > 1)
            print["remark"] =  JsTxt[71] + device.name +  JsTxt[72];
        testPrint.push(print);
    });
    let txt =  JsTxt[73];
    txt += JSON.stringify(testPrint, null, '\t');
    txt += " \`; \n\n";
    return txt;
}
// ======================================= LOG related functions
function doInitLog() { // delayed to reduce interferences
    popolateLogList();
    setInterval(logPolling, logInterval * 1000); // start loop logPolling
    initDataLog();
    if (autoSave > 0) {
        sleep(200);
        setInterval(autoLog, autoSave * 60 * 60 * 1000); // starts loop autosave
        console.log('autosave option = ' + autoSave + 'h');
    }
}
// User options data structure
function isLogged(device, status = null) {
    for (const dId of Object.keys(logListO)) {
        if (logListO[dId] && (logListO[dId].device_id === device.id)) {
            if (status == null)
                return true;
            if (logListO[dId].status_name === status)
                return true;
        }
    };
    return false;
}

// from config.LodList to logListO
function popolateLogList() {
    logListO = [];
    try {
        if (typeof(logList) == 'string')
            logList = JSON.parse(logList);
        else if (typeof(logList) != 'object') {
            return;
        }
    } catch (e) {
        alert(JsTxt[74]);
        return;
    }

    logList.forEach((set, lIndex) => {
        let item = {
            home: set.home,
            device_id: set.device || null, // now id OR name ! from user
            device_name: null,
            status_name: set.status,
            status_idx: 0,
            remark: '',
            ok: false,
        };
        let dev = getDeviceFromRef(set.device);
        let index = lIndex;
        //	  console.log("IN LOGLIST", set.device, dev);
        if (!dev)
            item.remark =  JsTxt[75];
        if (dev) {
            // more info for JSON output
            // set all item fields:
            item.device_id = dev.id;
            item.device_name = dev.name;
            item.home = tuyaData[dev.owner_id].name;
            // test for status
            var ival = dev.status.findIndex(rec => rec.code === item.status_name);
            index = dev.id;
            if (ival === undefined) {
                item.remark =  JsTxt[76];
            } else {
                item.ok = true;
                item.status_idx = ival;
                index += "_" + ival;
            }
        }
        // in any case: save
        logListO[index] = item;
    }); // loop set
    // console.log(logList, logListO);
}

//  LOGGING data  To TEXT
function logListToCode() {
    /*
    const logList =[
    [ device: "TF_frigo", status:"va_temperature"}, { device: "Temperatura studio", status:"va_temperature"},
    ];
     */
    /*
    var txt = ' const logList = [' + '\n';
    Object.keys(logListO).forEach((dId) => {
    let device = getDeviceFromRef(logListO[dId].device_id);
    let n = getCountName(logListO[dId].device_name);
    if ((!logListO[dId].ok) || (n > 1) || !device)
    txt += ' {
    device:  \ "' + logListO[dId].device_id;
    else
    txt += '          { device: \"' + device.name;

    txt += '\", status: " ' + logListO[dId].status_name + ' \ "}, ';
    if (device)
    txt += '   // ' + tuyaData[device.owner_id].name + '.' + device.name + '.' + logListO[dId].status_name;
    if (logListO[dId].remark || n > 1)
    txt += '\n            // ' + logListO[dId].remark;
    if (device && n > 1)
    txt += " WARNING - The name '" + device.name + "' is not unique - Use the ID ";

    txt += '\n';
    });
    txt += '		  ]; \n\r';
    return (txt);
     */
    let prnt = [];
    Object.keys(logListO).forEach((dId) => {
        let one = {}
        let device = getDeviceFromRef(logListO[dId].device_id);
        let n = getCountName(logListO[dId].device_name);
        if ((!logListO[dId].ok) || (n > 1) || !device) {
            one['home'] = logListO[dId].home;
            one['device'] = logListO[dId].device_id;
        } else {
            one['home'] = tuyaData[device.owner_id].name;
            one['device'] = device.name;
        }
        one['status'] = logListO[dId].status_name;

        if (logListO[dId].remark)
            one['remark'] = logListO[dId].remark;
        if (n > 1) {
            if (one['remark'])
                one['remark2'] = JsTxt[71] + device.name + JsTxt[72];
            else
                one['remark']  = JsTxt[71] + device.name + JsTxt[72];
        }
        prnt.push(one);
    });
    let txt =  JsTxt[77] ;
    txt += JSON.stringify(prnt, null, '\t');
    txt += " \`; \n\n";
    return txt;
}

function initDataLog() {
    if (datalog) {
        datalog.clear();
        console.log('Init data log ' + logFormat + ' @' + (new Date().toLocaleTimeString()));
        // first output line
        if (logFormat === 'CSV') {
            var lout = ["date", "time"];
            Object.keys(logListO).forEach((dId) => {
                if (logListO[dId].ok)
                    lout.push(logListO[dId].home + '.' + logListO[dId].device_name + '.' + logListO[dId].status_name);
            });
            // extension usrLog
            if (usrLog.length > 0) {
                for (const data of usrLog) {
                    lout.push(data[0]);
                }
            }
            datalog.log(lout);
        }
    }
}

function logPolling() {
    console.log(' Log polling @' + (new Date().toLocaleTimeString()));
    // updating values
    let d = new Date();
    d = new Date(d.getTime() - d.getTimezoneOffset() * 60000);
    Object.keys(logListO).forEach((dId) => {
        if (logListO[dId].ok) {
            let device = getDeviceFromRef(logListO[dId].device_id);
            logListO[dId].result = device.status[logListO[dId].status_idx].value;
        }
        logListO[dId]['day'] = d.toISOString().slice(0, 10);
        logListO[dId]['time'] = d.toISOString().slice(11, 19);
    });
    // putting log
    let lout = [];
    if (logFormat === 'CSV') {
        let init = true;
        Object.keys(logListO).forEach((dId) => {
            if (init) {
                lout.push(logListO[dId].day);
                lout.push(logListO[dId].time);
                init = false;
            }
            if (logListO[dId].ok)
                lout.push(logListO[dId].result);
        });
        // extension usrLog
        if (usrLog.length > 0) {
            for (const data of usrLog) {
                lout.push(data[1]);
            }
        }
        if (datalog)
            datalog.log(lout);
        else
            console.log(lout);
    }
    if (logFormat === 'JSON') {
        var outData = [];
        Object.keys(logListO).forEach((dId) => {
            if (logListO[dId].ok)
                outData.push(logListO[dId]);
        });
        // extension usrLog
        if (usrLog.length > 0) {
            for (const data of usrLog) {
                //			   home, device_name, device_id,  status_name, status_idx, ok, remark, date, time, value
                let usrval = {
                    home: 'none',
                    device_name: 'usr_rule',
                    device_id: 'rule@' + data[2],
                    status_name: data[0],
                    status_idx: 'none',
                    ok: true,
                    day: d.toISOString().slice(0, 10),
                    time: d.toISOString().slice(11, 19),
                    value: data[1]
                }
                outData.push(usrval);
            }
        }
        if (datalog)
            datalog.log(JSON.stringify(outData) + ',');
        else
            console.log(JSON.stringify(outData) + ',');
    }
}

function autoLog() {
    if (datalog) {
        console.log('Auto: sending ' + saveDataLog() + ' file');
        initDataLog();
    }
}

function saveDataLog() {
    if (datalog) {
        // 15/06 ver 2.1 modified
        // see https://discourse.nodered.org/t/node-red-filename-timestamp/22915
        const nowt = new Date().yyyymmddThhmmss();
        //	   let d = new Date();
        //	   d = new Date(d.getTime() - d.getTimezoneOffset() * 60000);
        //     const nowt = d.toISOString().slice(0, 10).replaceAll('-', '') + '.' + d.toISOString().slice(11, 19).replaceAll(':', '-');
        //      const nowt = new Date().toLocaleTimeString().replaceAll(':', '-');
        const filename = 'tuyalog.' + nowt;
        if (logFormat == 'CSV')
            datalog.logFilename = filename + '.csv.txt';
        if (logFormat == 'JSON')
            datalog.logFilename = filename + '.json.txt';
        datalog.downloadLog();
        return filename;
    }
    return null;
}
// ============== x-device functions
/*
            {name: "Temperatura studio",
             id: "xxxxxxxxxxxxxxxxxxxx",
             product_name: "温湿度传感器",
             model: null,
             category: "wsdcg",
             sub: true,
             logged: ["va_temperature"],
             test: false}
*/

  function doAddXDevice(xhome, xroom, xname, init, xcategory){
	  var info = {
                  id: "x-"+ Date.now(),
			    name:  xname || "custom",
	    product_name: "custom",
	           model: "user",
	        category:  xcategory || "x-dev",
	             sub: false,
         	  online: false,
              status: init || [],
              result: 0,
	            test: null  // mandatory
	             };
	            
	  for (const homeId of Object.keys(tuyaData)) {
		  if ( tuyaData[homeId]["name"] === xhome ){
      	        for (const device of tuyaData[homeId].devices) {
                   if (device.name === info.name)   {
			  		   device.status = init  || [];
			  		   return ;   // exists
			  	     }
			     };
			     
    if (nodesVis) {		
	 // adds	to home
           info["owner_id"] = homeId;
		   tuyaData[homeId]["devices"].push(info);
		   console.log("x-device: " + info.id);
// adds to room	(default home)
 		   tuyaData[homeId]['device_map'][info.id] = homeId.toString();
		   if (xroom)
			   tuyaData[homeId].rooms.forEach((room) => {
				   if (room.name === xroom) {
					   tuyaData[homeId]['device_map'][info.id] = room.room_id.toString();
					   }
					});
// add to tree
            var xnode =	createNode(info, 'x-device');
        	nodesVis.update([xnode]);
			edgesVis.update([{
            from: tuyaData[homeId]['device_map'][info.id],
            to: info.id,
			color: { color: "black" }
              }]);
            }
		    return;  // done
		     };
		  };
     throw ("ADDXDEVICE: Home "+xroom+" not found!");   
	  }

// UTILITY for CUSTOM dP processing, UPDATES/ADDS new value to any device.status
function  addToStatus(deviceName, code, value){
	const device =  getDeviceFromRef(deviceName);
	if ( device )
	     return setAnyStatus(device, code, value);
	}

function  addToXStatus(deviceName, code, value){
	const device =  getDeviceFromRef(deviceName);
	if ( device && device.id && device.id.startsWith("x-"))
	     return setAnyStatus(device, code, value);
//	throw "SETXDEVICESTATUS: x-device not found.";
    }

function setAnyStatus(device, code, value) {
    if  (device){
		let update = false;
		device.status.forEach((rec) => {
			if (rec.code  == code) {
			   rec.value = value;
			   update =  true;
			   }
		});
		if (update) return;
		device.status.push({code:code, value:value});
		return;
		};
	};

// ==============  TAP-TO-RUN page

function initTapToRun() {
    //	/v2.0/cloud/scene/rule?space_id=150***&page_size=2&page_no=1&type=automation
    Object.keys(tuyaData).forEach((home) => {
        // OPTION: room exclude
        let s = null;
        if (!(exclude_home.includes(home) || exclude_home.includes(tuyaData[home].name))) {
            tuyaData[home]['scenes'] = [];
            page = 1;
            //			do {
            sleep(200);
            //			 console.log('entro', page);
            s = callAPI('GET', "/v2.0/cloud/scene/rule?space_id=" + home + "&type=scene");
            if (s && s.list) {
                s.list.sort((a, b) => {
                    return a.name.localeCompare(b.name);
                });
                //		         console.log(s);
                tuyaData[home]['scenes'].push(...s.list);
            }
            page++;
            //			} while (s && s.has_more && page <11);

        }
    });
}

function setupTTPpage() {
    let pos = 1;
    let html1 = '';
    let html2 = '';

    Object.keys(tuyaData).forEach((home) => {
        // OPTION: room exclude
        if (!(exclude_home.includes(home) || exclude_home.includes(tuyaData[home].name))) {
            html1 += '<li class="nav-item"><a class="nav-link' + ((pos == 1) ? ' active' : '') + '" id="card-simple' + pos + '-tab" data-bs-toggle="tab" href="#card-simpletab' + pos + '" role="tab" aria-controls="card-simpletab' + pos + '" aria-selected="' + ((pos == 1) ? 'true' : 'false') + '">' + tuyaData[home].name + '</a></li>\n';

            html2 += '<div class="tab-pane p-4 fade' + ((pos == 1) ? ' show active' : '') + '" id="card-simpletab' + pos + '" role="tabpanel" aria-labelledby="card-simple' + pos + '-tab">';
            let i = 0;
            tuyaData[home]['scenes'].forEach((link) => {
                if (!(exclude_scene.includes(link.name) || exclude_scene.includes(link.id))) {
                    if (((i % 3) == 0) && (i > 0))
                        html2 += '</div><!-- close row1 -->';
                    if ((i % 3) == 0)
                        html2 += '<div class="row">\n';
                    let color = sceneColor(link);
                    html2 += '<div class="col-md-4 col-sm-4 col-xs-4"  style="margin-bottom:20px">';
                    html2 += '<button type="button" style="width:140px;" class="btn ' + color + '" onclick="doTTR(\'' + link.id + '\');">' + link.name + '</button></div>\n';
                    i++;
                }
            });
			if (i > 0)
                html2 += '</div><!-- close row2 -->';
            html2 += '</div>  <!-- close card-simpletab --> ';
            pos++;
        }
    });
	// EXTRA user RULE
	   html1 += '<li class="nav-item"><a class="nav-link' + ((pos == 1) ? ' active' : '') + '" id="card-simple' + pos + '-tab" data-bs-toggle="tab" href="#card-simpletab' + pos + '" role="tab" aria-controls="card-simpletab' + pos + '" aria-selected="' + ((pos == 1) ? 'true' : 'false') + '">' + "user RULE" + '</a></li>\n';
	   html2 += '<div class="tab-pane p-4 fade' + ((pos == 1) ? ' show active' : '') + '" id="card-simpletab' + pos + '" role="tabpanel" aria-labelledby="card-simple' + pos + '-tab"><div id="userRules">';
       html2 += '</div></div>  <!-- close card-simpletab --> ';

    html1 += '<li class="nav-item-filler"></li>';
    document.getElementById("card-simple").innerHTML = html1;
    document.getElementById("card-simpleContent").innerHTML = html2;
}

function addRULEbuttons(ruleList){
	    let html2 ='';
	    let i = 0;
        ruleList.forEach((rule) => {
                    if (((i % 3) == 0) && (i > 0))
                        html2 += '</div><!-- close row1 -->';
                    if ((i % 3) == 0)
                        html2 += '<div class="row">\n';
                    let color = sceneColor(rule);
                    html2 += '<div class="col-md-4 col-sm-4 col-xs-4"  style="margin-bottom:20px">';
                    html2 += '<button type="button" class="btn ' + color + '" onclick="ruleButton(\''+ rule + '\');">' + rule + '</button></div>\n';
                    i++;
            });
		 if (i > 0)
            html2 += '</div><!-- close row2 -->';
		document.getElementById("userRules").innerHTML = html2;
   }
// get id of a scene name or null // case insensitive
// 16/06/  modified
function getScene(txt) {
    let txtl = txt.toLowerCase();
    for (const home of Object.keys(tuyaData)) {
        if (tuyaData[home] && tuyaData[home]['scenes'] && tuyaData[home]['scenes'][0])
            for (const idx of Object.keys(tuyaData[home]['scenes'])) {
                if (tuyaData[home]['scenes'][idx].name.toLowerCase() == txtl)
                    return (tuyaData[home]['scenes'][idx].id);
            }
    }
    return (null);
}

function doTTR(id) {
    // POST: /v2.0/cloud/scene/rule/***/actions/trigger
    s = callAPI('POST', "/v2.0/cloud/scene/rule/" + id + "/actions/trigger");
}
